import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, ArrowUpRight, X } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useState } from 'react';

const projects = [
  {
    title: 'TechCraft Electronics',
    category: 'Fictional Tech Shop Concept',
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&q=80&w=2400',
    description: 'A clean-grid product showcase template designed for localized electronics retail, offering smooth category filters and detailed specification panels.',
  },
  {
    title: 'FixAll Phone Repair',
    category: 'Fictional Phone Repair Concept',
    image: 'https://images.unsplash.com/photo-1597740985671-2a8a3b80bf01?auto=format&fit=crop&q=80&w=2400',
    description: 'Interactive diagnostic layout prototype designed for technicians, facilitating damage diagnostics selection and local physical booking requests.',
  },
  {
    title: 'BiteExpress Diner',
    category: 'Fictional Fast Food & Takeaway Concept',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=2400',
    description: 'Visual menu architecture tailored for local takeaway restaurants, highlighting meal ingredients, meal deals, and simple contact guidelines.',
  },
  {
    title: 'ApexPower Gym',
    category: 'Fictional Modern Fitness Gym Concept',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&q=80&w=2400',
    description: 'A bold, high-contrast schedule and class table, optimized for local gyms to advertise class timings and lock in training enquiries.',
  },
  {
    title: 'VogueThread Co.',
    category: 'Fictional Clothing Brand Concept',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=2400',
    description: 'Lookbook grid built to showcase clothing items, featuring responsive sizing indices, and structured product lookups.',
  },
  {
    title: 'GreenEdge Landscaping',
    category: 'Fictional Local Services Concept',
    image: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&q=80&w=2400',
    description: 'A localized service engine showcasing beautiful image portfolios of completed work next to a simple project request mechanism.',
  },
];

export default function PortfolioSection() {
  const location = useLocation();
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  return (
    <section className="py-24 bg-[#0a0a0a] px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
            <div className="max-w-2xl">
                <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    className="text-blue-500 font-bold uppercase tracking-widest text-xs mb-4"
                >
                    Design Showcases
                </motion.div>
                <motion.h2
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-3xl md:text-6xl font-bold tracking-tight mb-4"
                >
                    Example Website <span className="text-white/40 italic">Concepts</span>
                </motion.h2>
                <motion.p
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    className="text-white/40 text-sm md:text-base leading-relaxed"
                >
                    These are fictional preview concepts demonstrating the calibre and type of professional websites SyncSites Co. can build for your business. We do not manufacture fake clients or reviews.
                </motion.p>
            </div>
            {location.pathname !== '/portfolio' ? (
              <Link
                  to="/portfolio"
                  className="group flex items-center gap-2 text-white/40 hover:text-white transition-colors uppercase text-xs font-bold tracking-widest shrink-0"
              >
                  View all concepts
                  <ArrowUpRight size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </Link>
            ) : (
              <div className="w-1" />
            )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {projects.map((project, idx) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.8 }}
              className="group cursor-pointer"
              onClick={() => setSelectedProject(project)}
            >
              <div className="relative overflow-hidden rounded-3xl bg-white/5 border border-white/10 mb-6 aspect-[16/10]">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-blue-600/20 mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-6 left-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    <span className="flex items-center gap-2 text-white font-bold tracking-tight text-sm uppercase">
                       <ExternalLink size={16} /> View Preview Design
                    </span>
                </div>
              </div>
              <div className="flex items-start justify-between px-2">
                <div>
                   <div className="text-blue-500 text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                     <span className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                     {project.category}
                   </div>
                   <h3 className="text-xl font-bold mb-2 group-hover:text-blue-400 transition-colors uppercase tracking-tight">{project.title}</h3>
                   <p className="text-white/40 text-xs leading-relaxed line-clamp-3">{project.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selectedProject && (
          <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             exit={{ opacity: 0 }}
             className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/90 backdrop-blur-xl"
             onClick={() => setSelectedProject(null)}
          >
             <motion.div 
                initial={{ scale: 0.95, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.95, y: 20, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="relative w-full max-w-6xl max-h-full flex flex-col bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden shadow-2xl"
             >
                <div className="flex-none p-6 border-b border-white/5 flex items-center justify-between">
                   <div>
                     <div className="text-blue-500 text-[10px] font-black uppercase tracking-widest mb-1.5">{selectedProject.category}</div>
                     <h3 className="text-2xl font-bold uppercase tracking-tight">{selectedProject.title}</h3>
                   </div>
                   <button 
                     onClick={() => setSelectedProject(null)}
                     className="p-3 bg-white/5 hover:bg-white/10 rounded-full transition-colors"
                   >
                      <X size={24} />
                   </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-0 relative bg-zinc-950">
                   {/* Conceptual full-page view wrapper */}
                   <div className="w-full relative flex flex-col min-h-[60vh] md:min-h-[70vh]">
                     
                     {/* MOCK WEBSITE TOP NAV */}
                     <div className="sticky top-0 z-20 bg-zinc-950/80 backdrop-blur-md border-b border-white/10 px-8 py-4 flex items-center justify-between">
                         <div className="text-xl font-black tracking-tighter uppercase">{selectedProject.title}</div>
                         <div className="hidden md:flex gap-6 text-[10px] font-bold uppercase tracking-widest text-white/50">
                             <span>Home</span>
                             <span>Services</span>
                             <span>About</span>
                             <span>Contact</span>
                         </div>
                         <button className="px-4 py-2 bg-white text-black text-[10px] rounded font-bold uppercase tracking-widest">Action</button>
                     </div>

                     {/* MOCK WEBSITE HERO */}
                     <div className="relative min-h-[50vh] flex flex-col items-center justify-center text-center p-8 border-b border-white/5">
                         <img 
                           src={selectedProject.image} 
                           alt={selectedProject.title}
                           className="absolute inset-0 w-full h-full object-cover opacity-30"
                         />
                         <div className="absolute inset-0 bg-gradient-to-b from-transparent via-zinc-950/60 to-zinc-950" />
                         
                         <div className="relative z-10 max-w-3xl mx-auto">
                            <h4 className="text-4xl md:text-6xl font-bold tracking-tighter uppercase mb-6 drop-shadow-2xl">{selectedProject.title}</h4>
                            <p className="text-white/60 text-lg md:text-xl font-medium mb-8 max-w-2xl mx-auto drop-shadow-lg leading-relaxed">{selectedProject.description}</p>
                            <button className="px-8 py-4 bg-white text-black font-bold uppercase tracking-widest text-xs rounded-full shadow-xl">
                                Explore Services
                            </button>
                         </div>
                     </div>

                     {/* MOCK WEBSITE CONTENT SECTIONS */}
                     <div className="bg-zinc-950 p-8 md:p-16 space-y-16">
                         {/* Services Grid Mock */}
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {[1, 2, 3].map((item) => (
                               <div key={item} className="p-8 bg-white/5 border border-white/5 rounded-2xl flex flex-col items-center text-center">
                                  <div className="w-12 h-12 bg-white/10 rounded-full mb-6" />
                                  <div className="h-4 w-32 bg-white/20 rounded mb-4" />
                                  <div className="h-2 w-full bg-white/10 rounded mb-2" />
                                  <div className="h-2 w-5/6 bg-white/10 rounded" />
                               </div>
                            ))}
                         </div>

                         {/* Text Image split Mock */}
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center border-t border-white/5 pt-16">
                             <div className="space-y-6">
                                <div className="text-[10px] text-blue-500 font-bold uppercase tracking-widest">Premium Quality</div>
                                <h3 className="text-3xl font-bold tracking-tight uppercase">Elevating the standard of service.</h3>
                                <div className="space-y-3">
                                   <div className="h-2 w-full bg-white/10 rounded" />
                                   <div className="h-2 w-full bg-white/10 rounded" />
                                   <div className="h-2 w-4/5 bg-white/10 rounded" />
                                </div>
                             </div>
                             <div className="aspect-video bg-white/5 border border-white/10 rounded-3xl overflow-hidden relative">
                               <img 
                                 src={selectedProject.image} 
                                 alt={selectedProject.title}
                                 className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale mix-blend-overlay"
                               />
                             </div>
                         </div>
                     </div>
                     
                     {/* MOCK WEBSITE FOOTER */}
                     <div className="border-t border-white/10 bg-black p-8 md:p-16 mt-auto">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-white/10">
                           <div className="col-span-2">
                               <div className="text-2xl font-black tracking-tighter uppercase mb-4">{selectedProject.title}</div>
                               <div className="h-2 w-48 bg-white/10 rounded mb-2" />
                               <div className="h-2 w-32 bg-white/10 rounded" />
                           </div>
                           <div>
                              <div className="h-3 w-24 bg-white/20 rounded mb-4" />
                              <div className="space-y-3">
                                <div className="h-2 w-16 bg-white/10 rounded" />
                                <div className="h-2 w-20 bg-white/10 rounded" />
                                <div className="h-2 w-16 bg-white/10 rounded" />
                              </div>
                           </div>
                           <div>
                              <div className="h-3 w-24 bg-white/20 rounded mb-4" />
                              <div className="space-y-3">
                                <div className="h-2 w-16 bg-white/10 rounded" />
                                <div className="h-2 w-20 bg-white/10 rounded" />
                              </div>
                           </div>
                        </div>
                        <div className="flex justify-between items-center text-[10px] text-white/40 uppercase tracking-widest font-bold">
                            <span>© {new Date().getFullYear()} {selectedProject.title}</span>
                            <span>Powered by SyncSites Co.</span>
                        </div>
                     </div>

                     {/* MOCK WEBSITE FLOATING CTA (Enquire) */}
                     <div className="sticky bottom-0 z-30 p-4 bg-zinc-950/90 border-t border-white/10 backdrop-blur-xl flex justify-between items-center">
                        <div className="text-white/60 text-xs font-bold uppercase tracking-widest hidden md:block">
                            Demonstration Mode
                        </div>
                        <Link 
                           to="/enquiry" 
                           onClick={() => setSelectedProject(null)}
                           className="px-6 py-3 bg-blue-600 w-full md:w-auto text-center text-white font-bold uppercase tracking-widest text-xs rounded-lg hover:bg-blue-500 transition-colors shadow-xl shadow-blue-500/20"
                        >
                           Enquire Similar Concept
                        </Link>
                     </div>

                   </div>
                </div>
             </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
