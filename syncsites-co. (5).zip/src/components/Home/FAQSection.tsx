import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqs = [
  {
    question: 'How long does it take to launch my website?',
    answer: 'Our average delivery time is 3–6 business days for the Basic Website Package and 7–10 business days for the Bespoke Website Package, depending on requirements complexity and initial briefing.',
  },
  {
    question: 'How does the process work?',
    answer: 'First, select your preferred package to place a priority hold in our pipeline. Second, fill out our consultation detail form. Our lead developer reviews your brief and hosts a secure strategy call. We build, setup, and publish your site upon your final sign-off.',
  },
  {
    question: 'What does the monthly management fee cover?',
    answer: 'The monthly management fee covers professional website hosting, ongoing technical maintenance, fixing visual or code errors, quick support response times, server/access performance monitoring, keeping the website fully operational, and simple content updates requested by you.',
  },
  {
    question: 'What is included in the Basic Website Package?',
    answer: 'The Basic Website Package is a complete, custom one-time build that includes fully hand-coded design layouts, complete publishing setup, mobile optimization, and standard business brand pages (About, Services, Contact, etc.). It does not include ongoing monthly management or content edits.',
  },
  {
    question: 'What is included in the Bespoke Website Package?',
    answer: 'The Bespoke Website Package includes a fully custom tailored design, advanced responsive section structures, deeper collaborative planning, and complete ongoing monthly management, ensuring your business stays perfectly aligned.',
  },
  {
    question: 'How do you handle technical support and issues?',
    answer: 'For managed sites, we provide quick support response times and fast issue resolution to keep your business online without hitches. We perform constant performance monitoring to ensure perfect uptime.',
  },
  {
    question: 'Are your websites mobile responsive and SEO optimized?',
    answer: 'Absolutely. Every single website build starts with mobile responsiveness and speed as core principles. We write clean, semantic code that is natively structured for search engines (SEO basics) to aid crawlability and discovery.',
  },
];

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

function FAQItem({ question, answer, isOpen, onClick }: FAQItemProps) {
  return (
    <div className="border-b border-white/5 last:border-0">
      <button
        onClick={onClick}
        className="w-full py-6 flex items-center justify-between text-left group"
      >
        <span className="text-lg font-bold group-hover:text-blue-400 transition-colors uppercase tracking-tight">{question}</span>
        {isOpen ? <ChevronUp className="text-blue-500" /> : <ChevronDown className="text-white/20" />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <p className="pb-8 text-white/40 leading-relaxed text-sm max-w-2xl">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
            <h2 className="text-3xl md:text-6xl font-bold mb-6 tracking-tight">Frequently Asked <span className="text-white/40 italic">Questions</span></h2>
            <p className="text-white/40 text-lg">Everything you need to know about partnering with SyncSites.</p>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-3xl px-10 py-4 shadow-xl backdrop-blur-sm">
          {faqs.map((faq, idx) => (
            <div key={idx}>
              <FAQItem
                question={faq.question}
                answer={faq.answer}
                isOpen={openIndex === idx}
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
