import { motion } from 'motion/react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function FinalCTA() {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           transition={{ duration: 0.8 }}
           className="relative p-12 md:p-24 rounded-3xl bg-blue-600 overflow-hidden shadow-[0_0_100px_rgba(37,99,235,0.3)] text-center flex flex-col items-center border border-white/20 backdrop-blur-sm"
        >
          {/* Decorative assets */}
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-white/10 rounded-full blur-[100px]" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-blue-400/20 rounded-full blur-[100px]" />

          <motion.div
             animate={{ rotate: 360 }}
             transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
             className="w-20 h-20 border-2 border-white/20 rounded-full flex items-center justify-center mb-10 relative z-10"
          >
             <Sparkles className="text-white" size={32} />
          </motion.div>

          <h2 className="text-4xl md:text-8xl font-bold text-white mb-8 tracking-tighter leading-[0.9] relative z-10 uppercase">
             Your Business Deserves<br />Better Than Average
          </h2>
          <p className="text-blue-50 text-xl md:text-2xl mb-12 max-w-2xl mx-auto leading-relaxed relative z-10">
             Get a professional online presence that helps your business grow, attract premium customers, and stand out from competitors.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 items-center relative z-10">
             <Link
               to="/contact"
               className="px-10 py-5 bg-white text-black rounded-xl font-bold text-xl hover:scale-105 transition-transform flex items-center gap-2 shadow-2xl uppercase tracking-tight"
             >
               Start Project Today
               <ArrowRight size={24} />
             </Link>
             <Link
                to="/portfolio"
                className="text-white text-lg font-bold hover:underline underline-offset-8 decoration-2 decoration-blue-200 transition-all uppercase tracking-widest text-sm"
             >
                See Our Latest Work
             </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
