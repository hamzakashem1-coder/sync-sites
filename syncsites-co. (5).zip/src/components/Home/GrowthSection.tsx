import { motion } from 'motion/react';
import { Target, ShieldCheck, Zap, Layers, RefreshCw } from 'lucide-react';

const performanceFactors = [
  { 
    label: 'Lighthouse Target', 
    value: '95+', 
    description: 'Custom-coded builds completely bypass bloated theme engines and sluggish layout plugins.',
    icon: Target
  },
  { 
    label: 'Core Web Vitals Target', 
    value: '< 1s LCP', 
    description: 'Near-instant Largest Contentful Paint minimizes bounce rates and sustains premium indexing on search engines.',
    icon: Zap
  },
  { 
    label: 'Responsive Fidelity', 
    value: '100% Fluid', 
    description: 'Hand-crafted CSS layouts rendering cleanly without relying on brittle automated resizing scripts.',
    icon: ShieldCheck
  },
  { 
    label: 'Technical Hygiene', 
    value: 'Zero Bloat', 
    description: 'Bespoke semantic markup with optimized script delivery ensures outstanding network diagnostics.',
    icon: Layers
  },
];

export default function GrowthSection() {
  return (
    <section className="py-24 px-6 relative overflow-hidden bg-black/40 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="font-sans"
            >
                <div className="text-blue-500 font-bold uppercase tracking-widest text-xs mb-4">ENGINEERING TRUTHS</div>
                <h2 className="text-3xl md:text-5xl font-bold mb-8 leading-tight tracking-tight uppercase italic font-sans text-white">
                    The Factual Math of Website Speed
                </h2>
                <p className="text-white/60 text-lg leading-relaxed mb-6">
                    A great website is a silent business asset. The average modern consumer leaves a web page if it fails to load within three seconds. By prioritizing pristine code efficiency, we ensure physical traffic translates seamlessly to real client enquiries.
                </p>
                <p className="text-white/40 text-sm leading-relaxed mb-8">
                    We steer completely clear of low-end template generators or drag-and-drop page configurations that overload your systems. By utilizing bespoke code elements, your business credibility, SEO rank, and consumer trust are systematically fortified.
                </p>
                
                <div className="flex items-center gap-3 text-white/40 text-xs uppercase font-black tracking-widest">
                  <RefreshCw size={14} className="text-blue-500 animate-spin" />
                  <span>Verified performance diagnostics mapping active</span>
                </div>
            </motion.div>

            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-6 relative"
            >
              <div className="absolute -inset-10 bg-blue-600/5 rounded-full blur-3xl -z-10 pointer-events-none" />
              {performanceFactors.map((factor, idx) => {
                const Icon = factor.icon;
                return (
                  <motion.div
                      key={factor.label}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1 }}
                      className="p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-all font-sans flex flex-col justify-between"
                  >
                      <div>
                        <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-400 mb-6 border border-blue-500/5">
                           <Icon size={18} />
                        </div>
                        <div className="text-3xl font-bold text-white mb-1 font-sans tracking-tight italic">{factor.value}</div>
                        <div className="text-[10px] uppercase font-black text-white/30 tracking-widest mb-3">{factor.label}</div>
                      </div>
                      <p className="text-white/50 text-xs leading-relaxed font-sans">{factor.description}</p>
                  </motion.div>
                );
              })}
            </motion.div>
        </div>
      </div>
    </section>
  );
}
