import { motion } from 'motion/react';
import { ShieldCheck, Zap, Activity, Award } from 'lucide-react';

const benchmarks = [
  {
    title: 'Speed & Core Web Vitals',
    metric: '98/100',
    subtitle: 'Lighthouse Performance Peak',
    description: 'Every millisecond of lag costs conversions. Our hand-coded React-Vite frameworks are engineered specifically to break loading boundaries without sluggish systems or heavy CMS bloat.',
    icon: Zap,
  },
  {
    title: 'SEO Crawling Index',
    metric: '100%',
    subtitle: 'System Semantic Accuracy',
    description: 'Pristine markup leads directly to premium domain search visibility. We inject structural JSON schemas and completely crawl-ready HTML tags into every layout to maximize indexing potential.',
    icon: Activity,
  },
  {
    title: 'Conversion Experience',
    metric: '2.5x',
    subtitle: 'Average Lead Action Increase',
    description: 'An online presence is a growth vehicle. We eliminate friction with high-impact layouts, streamlined inquiry paths, and authoritative typography designed to convert standard traffic into active clients.',
    icon: Award,
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-24 bg-zinc-950 px-6 relative overflow-hidden">
      {/* Background ambient light and container */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-blue-600/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-3 py-1 bg-blue-600/10 border border-blue-500/20 rounded-full text-blue-500 text-[10px] font-black uppercase tracking-widest mb-6 animate-pulse"
          >
            <ShieldCheck size={12} />
            Performance Guarantee
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-7xl font-bold mb-6 tracking-tighter uppercase"
          >
            Our Uncompromising <span className="text-white/40 italic">Delivery Index</span>
          </motion.h2>
          <p className="text-white/40 text-lg max-w-2xl mx-auto font-medium">
            We don't rely on generic templates or unverified claims. We prioritize real-world engineering speed, precise structural SEO, and robust lead acquisition architectures.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benchmarks.map((b, idx) => {
            const Icon = b.icon;
            return (
              <motion.div
                key={b.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-10 rounded-[32px] bg-white/[0.02] border border-white/5 relative group hover:bg-white/[0.05] hover:border-white/10 transition-all duration-300 backdrop-blur-sm"
              >
                <div className="flex items-start justify-between mb-8">
                  <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-all shadow-lg shadow-blue-500/0">
                     <Icon size={20} />
                  </div>
                  <div className="text-right">
                     <div className="text-4xl font-black text-white italic tracking-tighter leading-none mb-1 group-hover:text-blue-400 transition-colors uppercase">{b.metric}</div>
                     <div className="text-[10px] text-white/40 font-bold uppercase tracking-widest">{b.subtitle}</div>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-4 text-white uppercase tracking-tight">{b.title}</h3>
                <p className="text-white/40 leading-relaxed text-sm">{b.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

