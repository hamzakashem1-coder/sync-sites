import { motion } from 'motion/react';
import { AlertTriangle, PhoneOff, Smartphone, ShieldAlert, CheckCircle, Info, Sparkles, Globe, UserCheck, MessageSquare } from 'lucide-react';

const consequences = [
  {
    icon: ShieldAlert,
    title: 'No Website / Outdated Design',
    description: 'Failing to maintain a professional, up-to-date online address signals insecurity or neglect, crippling customer trust and business legitimacy before the first conversation.',
  },
  {
    icon: Smartphone,
    title: 'Poor Mobile Experience',
    description: 'Over 60% of organic traffic is on mobile devices. A non-responsive layout frustrates users and immediately pushes them to look for alternative providers.',
  },
  {
    icon: AlertTriangle,
    title: 'Slow Website Speeds',
    description: 'Modern consumers expect near-instant interactions. Outdated codebases load slowly, causing visitors to bounce and lowering search visibility.',
  },
  {
    icon: PhoneOff,
    title: 'Unclear Contact & Details',
    description: 'If operational hours, email links, or simple inquiry options are hidden or ambiguous, customers abandon their search and contact competitors instead.',
  },
];

const benefits = [
  {
    icon: UserCheck,
    title: 'Business Legitimacy & Trust',
    description: 'Establishes verified digital authority. A secure, structured presence communicates stability and professional commitment.',
  },
  {
    icon: Globe,
    title: 'Online Visibility & Discovery',
    description: 'Enables your business to show up directly during buyer-intent queries in local search engines, ensuring continuous lead opportunity.',
  },
  {
    icon: MessageSquare,
    title: 'Frictionless Customer Contact',
    description: 'Presents crystal-clear enquiry forms and structured consultation booking prompts, lowering barriers to transactional conversations.',
  },
  {
    icon: Sparkles,
    title: 'First-Class First Impression',
    description: 'Captures and retains user interest through refined typography, clean page layouts, and logical text flow that commands attention.',
  },
];

export default function ProblemSection() {
  return (
    <section className="py-24 bg-black px-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Consequences Section */}
        <div className="mb-24">
          <div className="text-center mb-16">
            <span className="text-red-500 font-bold uppercase tracking-widest text-[10px] bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full">
              Critical Business Risks
            </span>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-bold mt-6 mb-4 tracking-tight uppercase"
            >
              The Consequences of <span className="text-white/40 italic">Poor Infrastructure</span>
            </motion.h2>
            <p className="text-white/40 text-sm max-w-2xl mx-auto uppercase font-bold tracking-wider leading-relaxed">
              Failing to maintain a polished website can actively damage brand reputation. Outdated setups, poor usability, and sluggish load times drive buyers away.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {consequences.map((problem, idx) => (
              <motion.div
                key={problem.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:border-red-500/20 transition-all group"
              >
                <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-red-500/10 group-hover:text-red-400 transition-all text-white/40">
                  <problem.icon size={26} />
                </div>
                <h3 className="text-lg font-bold mb-3 uppercase tracking-tight">{problem.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed font-medium">{problem.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Benefits Section */}
        <div>
          <div className="text-center mb-16">
            <span className="text-blue-500 font-bold uppercase tracking-widest text-[10px] bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full">
              Strategic Advantages
            </span>
            <motion.h3
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-bold mt-6 mb-4 tracking-tight uppercase"
            >
              Why a Premium Website <span className="text-white/40 italic">Matters</span>
            </motion.h3>
            <p className="text-white/40 text-sm max-w-2xl mx-auto uppercase font-bold tracking-wider leading-relaxed">
              A high-end website serves as your 24/7 digital front-office. It positions your brand with professional authority, builds visitor trust, and opens frictionless communication channels.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, idx) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:border-blue-500/20 transition-all group"
              >
                <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-blue-500/10 group-hover:text-blue-400 transition-all text-white/40">
                  <benefit.icon size={26} />
                </div>
                <h3 className="text-lg font-bold mb-3 uppercase tracking-tight text-white">{benefit.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed font-medium">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           whileInView={{ opacity: 1, scale: 1 }}
           viewport={{ once: true }}
           className="mt-20 p-12 rounded-[2.5rem] bg-gradient-to-br from-blue-500/5 to-transparent border border-blue-500/10 text-center"
        >
           <p className="text-blue-400 font-bold uppercase tracking-[0.2em] text-xs mb-4">Credibility Index</p>
           <p className="text-xl md:text-2xl font-medium text-white max-w-3xl mx-auto leading-relaxed italic font-serif">
             "Legitimacy, clear mobile accessibility, and ease of customer contact establish a strong, professional first impression that forms the bedrock of customer decision making."
           </p>
        </motion.div>

      </div>
    </section>
  );
}
