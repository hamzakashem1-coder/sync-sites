import { motion } from 'motion/react';
import { Check, X } from 'lucide-react';

const comparison = [
    { feature: 'High-End Custom Design', syncSites: true, generic: false },
    { feature: 'Conversion Logic Built-In', syncSites: true, generic: false },
    { feature: 'Ongoing Growth Support', syncSites: true, generic: false },
    { feature: 'Mobile-First Architecture', syncSites: true, generic: 'Sometimes' },
    { feature: 'Technical Management', syncSites: true, generic: false },
    { feature: 'Affordable Transparent Pricing', syncSites: true, generic: 'Rarely' },
];

export default function WhyChooseSection() {
    return (
        <section className="py-24 px-6 relative overflow-hidden">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">Why <span className="text-blue-500">SyncSites Co.</span> Beats the Competition</h2>
                    <p className="text-white/40 text-lg">Don't settle for "good enough" when you can have a growth partner.</p>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-sm">
                    <div className="grid grid-cols-3 border-b border-white/10 p-8 bg-white/5">
                        <div className="text-white/30 font-bold uppercase tracking-widest text-[10px] self-center">Feature</div>
                        <div className="text-blue-500 font-black text-center text-[10px] uppercase tracking-[0.2em]">SyncSites Co.</div>
                        <div className="text-white/30 font-bold text-center text-[10px] uppercase tracking-widest italic">The Others</div>
                    </div>
                    {comparison.map((item, idx) => (
                        <div key={item.feature} className="grid grid-cols-3 p-8 border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                            <div className="text-sm font-medium text-white/80 self-center tracking-tight">{item.feature}</div>
                            <div className="flex justify-center items-center">
                                <div className="w-8 h-8 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500">
                                    <Check size={18} strokeWidth={3} />
                                </div>
                            </div>
                            <div className="flex justify-center items-center">
                                {item.generic === 'Sometimes' || item.generic === 'Rarely' ? (
                                    <span className="text-xs italic text-white/20 font-medium">{item.generic}</span>
                                ) : (
                                    <div className="w-8 h-8 rounded-full bg-red-600/5 flex items-center justify-center text-red-900/40">
                                        <X size={18} strokeWidth={2} />
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
