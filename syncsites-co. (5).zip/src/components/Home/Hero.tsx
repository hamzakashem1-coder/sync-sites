import { motion } from 'motion/react';
import { ShieldCheck, Zap, MonitorSmartphone } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[0%] right-[-5%] w-[35%] h-[35%] bg-blue-800/10 rounded-full blur-[120px]" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150" />
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-bold uppercase tracking-widest mb-6"
          >
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
            Professional Digital Real Estate
          </motion.div>

          <h1 className="text-6xl md:text-8xl font-bold leading-[0.9] tracking-tighter mb-8 uppercase">
            Websites <span className="text-blue-600">Designed</span><br/>
            <span className="text-white/40 italic">to Build Trust.</span>
          </h1>

          <p className="text-xl text-white/50 max-w-xl leading-relaxed mb-10 font-medium">
            SyncSites Co. designs and manages high-quality, professional websites. We ensure your business is perceived with the credibility, performance, and legitimacy it deserves.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Link
              to="/contact"
              className="px-8 py-4 bg-blue-600 rounded-xl font-bold text-lg hover:bg-blue-500 hover:scale-105 transition-all shadow-[0_0_30px_rgba(37,99,235,0.4)] flex items-center justify-center"
            >
              Start Consultation
            </Link>
            <Link
              to="/packages"
              className="px-8 py-4 bg-white/5 border border-white/10 rounded-xl font-bold text-lg hover:bg-white/10 transition-all flex items-center justify-center text-white"
            >
              View Packages
            </Link>
          </div>

          <div className="mt-12 flex flex-wrap gap-8">
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                 <MonitorSmartphone size={20} />
               </div>
               <div>
                  <div className="font-bold uppercase tracking-tight text-sm">Mobile Optimized</div>
                  <div className="text-[10px] text-white/40 uppercase tracking-widest">Fully Responsive Layouts</div>
               </div>
             </div>
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                 <Zap size={20} />
               </div>
               <div>
                  <div className="font-bold uppercase tracking-tight text-sm">High Performance</div>
                  <div className="text-[10px] text-white/40 uppercase tracking-widest">Hand-Written Optimisation</div>
               </div>
             </div>
              <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                 <ShieldCheck size={20} />
               </div>
               <div>
                  <div className="font-bold uppercase tracking-tight text-sm">Secure Management</div>
                  <div className="text-[10px] text-white/40 uppercase tracking-widest">Ongoing Maintenance</div>
               </div>
             </div>
          </div>
        </motion.div>

        <motion.div
           initial={{ opacity: 0, scale: 0.8 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1, delay: 0.4, ease: 'easeOut' }}
           className="relative hidden lg:block"
        >
          <div className="relative z-10 bg-white/5 rounded-[2.5rem] border border-white/10 p-4 shadow-2xl backdrop-blur-xl">
            <img
              src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=2426"
              alt="Dashboard Analytics Mockup"
              className="rounded-[1.5rem] w-full h-auto grayscale opacity-80"
              referrerPolicy="no-referrer"
            />
            {/* Floating elements */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -top-6 -right-6 p-6 bg-white/5 border border-white/10 backdrop-blur-2xl rounded-3xl shadow-2xl"
            >
               <div className="text-white/20 text-[10px] uppercase font-bold tracking-[0.2em] mb-2 leading-none">Code Architecture</div>
               <div className="text-3xl font-bold tracking-tighter">SEO<span className="text-blue-500"> Ready</span></div>
            </motion.div>

             <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -bottom-8 -left-8 p-6 bg-blue-600 rounded-3xl shadow-2xl shadow-blue-600/30 border border-white/20"
            >
               <div className="text-blue-100 text-[10px] uppercase font-bold tracking-[0.2em] mb-2 leading-none">System Status</div>
               <div className="text-2xl font-bold uppercase tracking-tight">Active Operation</div>
            </motion.div>
          </div>
          {/* Decorative glow behind image */}
          <div className="absolute inset-0 bg-blue-500/20 blur-[100px] -z-10" />
        </motion.div>
      </div>
    </section>
  );
}
