import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

const steps = [
  {
    id: '01',
    title: 'Discovery & Audit',
    subtitle: 'Tell Us About Your Business',
    description: 'We dive deep into your goals, current presence, and competitors to define a strategy that wins.',
  },
  {
    id: '02',
    title: 'Design & Development',
    subtitle: 'We Build Your Vision',
    description: 'Our world-class team crafts your custom website with a focus on premium aesthetics and conversion logic.',
  },
  {
    id: '03',
    title: 'Launch & Expansion',
    subtitle: 'Grow Your Dominance',
    description: 'We launch your site and provide ongoing growth support to ensure your business continues to scale.',
  },
];

export default function ProcessSection() {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      {/* Decorative vertical lines */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-5">
        <div className="h-full w-[1px] bg-white absolute left-1/4" />
        <div className="h-full w-[1px] bg-white absolute left-1/2" />
        <div className="h-full w-[1px] bg-white absolute left-3/4" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
         <div className="text-center mb-24">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="inline-block px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-[10px] font-black uppercase tracking-widest mb-6"
            >
              The Blueprint
            </motion.div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-6xl font-bold tracking-tight"
            >
              How We Turn Browsers <span className="text-blue-500">Into Buyers</span>
            </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {steps.map((step, idx) => (
                <motion.div
                    key={step.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.2 }}
                    className="relative"
                >
                    <div className="mb-8">
                        <span className="text-8xl font-black text-white/[0.03] absolute -top-12 -left-4 select-none group-hover:text-blue-500/10 transition-colors">
                            {step.id}
                        </span>
                        <div className="relative z-10">
                            <h4 className="text-blue-500 font-bold uppercase tracking-widest text-[11px] mb-2">{step.title}</h4>
                            <h3 className="text-2xl font-bold mb-4 tracking-tight">{step.subtitle}</h3>
                            <p className="text-white/40 leading-relaxed text-sm">{step.description}</p>
                        </div>
                    </div>
                    {idx < steps.length - 1 && (
                        <div className="hidden md:block absolute top-10 -right-6 text-white/10">
                            <ArrowRight size={32} />
                        </div>
                    )}
                </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
}
