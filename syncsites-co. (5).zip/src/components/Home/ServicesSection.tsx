import { motion } from 'motion/react';
import { Target, ShieldCheck, Zap, BarChart3, Globe, Smartphone, Headphones } from 'lucide-react';

const services = [
  {
    icon: Target,
    title: 'Custom Website Design',
    description: 'Bespoke designs tailored to your brand identity and business goals. No templates, just results.',
  },
  {
    icon: Smartphone,
    title: 'Mobile Optimization',
    description: 'We ensure a flawless experience on every device. Your business looks elite in any palm.',
  },
  {
    icon: BarChart3,
    title: 'SEO Foundations',
    description: 'Built-in SEO structure to ensure your site is readable by Google and visible to your customers.',
  },
  {
    icon: Zap,
    title: 'Performance & Speed',
    description: 'Ultra-fast loading times that keep visitors engaged and improve your search engine rankings.',
  },
  {
    icon: ShieldCheck,
    title: 'Hosting & Security',
    description: 'Secure, high-bandwidth SSD hosting combined with SSL certificates and active system health checks to preserve website performance.',
  },
  {
    icon: Headphones,
    title: 'Ongoing Maintenance',
    description: 'Comprehensive code fixes, stylesheet corrections, on-request content adjustments, and exceptionally quick support response times.',
  },
];

export default function ServicesSection() {
  return (
    <section className="py-24 bg-zinc-950 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div className="max-w-xl">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-blue-500 font-bold uppercase tracking-widest text-xs mb-4"
            >
              Our Expertise
            </motion.div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl md:text-5xl font-bold"
            >
              Comprehensive Solutions for <span className="text-zinc-500">Business Transformation</span>
            </motion.h2>
          </div>
          <motion.p
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             className="text-zinc-400 text-lg md:max-w-sm"
          >
            We provide everything you need to attract, engage, and convert customers in the modern digital landscape.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 rounded-3xl bg-zinc-900 border border-zinc-800 hover:border-blue-500/50 hover:bg-zinc-900/50 transition-all group overflow-hidden relative"
            >
              {/* Subtle background glow on hover */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-blue-600/5 rounded-full blur-2xl group-hover:bg-blue-600/20 transition-all" />

              <div className="w-12 h-12 bg-zinc-800 rounded-xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all text-blue-500">
                <service.icon size={24} />
              </div>
              <h3 className="text-xl font-bold mb-4">{service.title}</h3>
              <p className="text-zinc-500 text-sm leading-relaxed relative z-10">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
