import { motion } from 'motion/react';
import { usePackage } from '../../context/PackageContext';
import { useNavigate } from 'react-router-dom';
import { Check, Info } from 'lucide-react';
import { cn } from '../../lib/utils';

const buildPackages = [
  {
    id: 'basic-build',
    name: 'Basic Website Package',
    price: 150,
    type: 'Website Design',
    description: 'A clean, professional online presence to establish your business credibility and legitimacy.',
    deliveryTime: '3–6 business days',
    features: [
      'Professional website build & setup',
      '100% mobile-responsive layout',
      'Standard pages (Home, About, Contact)',
      'Optimised for search engines (SEO base)',
      'Clean hand-coded framework'
    ],
    recommended: false,
  },
  {
    id: 'bespoke-build',
    name: 'Bespoke Website Package',
    price: 250,
    type: 'Custom Architecture',
    description: 'Fully custom tailored website architecture with advanced section layouts and collaborative creative planning.',
    deliveryTime: '7–10 business days',
    features: [
      'Everything in Basic Build',
      'Fully tailored design & high-end layouts',
      'Deep, collaborative planning phase',
      'Advanced animations and transitions',
      'Priority delivery schedule',
    ],
    recommended: true,
  },
];

const monthlyPackages = [
  {
    id: 'essential-care',
    name: 'Essential Management',
    price: 20,
    type: 'Monthly Support',
    description: 'Keep your website online, fast, and bug-free.',
    features: [
      'Secure SSD Hosting',
      'SSL Certificate & Security Checks',
      'Basic minor text/image updates',
      'Error & problem handling'
    ],
    recommended: false,
  },
  {
    id: 'premium-care',
    name: 'Premium Management',
    price: 49.99,
    type: 'Monthly Support',
    description: 'Comprehensive management with regular design enhancements and priority care.',
    features: [
      'Everything in Essential',
      'Proper updates & design changes',
      'Regular contact & development help',
      'Proactive performance monitoring'
    ],
    recommended: true,
  }
];

export default function PackagesSection() {
  const { selectPackage } = usePackage();
  const navigate = useNavigate();

  const handleSelect = (pkg: typeof buildPackages[0], monthlyPkg?: typeof monthlyPackages[0]) => {
    selectPackage({
      id: pkg.id,
      name: pkg.name,
      price: pkg.price,
      setupFee: pkg.price,
      monthlyFee: monthlyPkg ? monthlyPkg.price : 0,
    });
    navigate('/enquiry');
  };

  return (
    <section id="packages" className="py-24 bg-zinc-950 px-6 relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 blur-[150px] -z-10 rounded-full" />

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-7xl font-bold mb-6 tracking-tighter uppercase"
          >
            Website <span className="text-white/40 italic">Packages</span>
          </motion.h2>
          <motion.p
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ delay: 0.1 }}
             className="text-white/40 text-lg max-w-2xl mx-auto font-medium"
          >
            Transparent pricing for your website build. (Monthly hosting & support options available at enquiry).
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 max-w-5xl mx-auto gap-8 items-stretch mb-24">
          {buildPackages.map((pkg, idx) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              whileHover={{ 
                y: -10, 
                boxShadow: pkg.recommended 
                  ? "0 30px 60px -15px rgba(37,99,235,0.4)" 
                  : "0 30px 60px -15px rgba(255,255,255,0.1)",
                borderColor: pkg.recommended ? "rgba(59,130,246,0.6)" : "rgba(255,255,255,0.2)"
              }}
              viewport={{ once: true }}
              transition={{ 
                delay: idx * 0.1, 
                duration: 0.6,
                whileHover: { duration: 0.3 }
              }}
              className={cn(
                'relative p-8 rounded-3xl border transition-all flex flex-col backdrop-blur-sm group/card',
                pkg.recommended
                  ? 'bg-gradient-to-br from-blue-600/20 to-transparent border-blue-500/40 shadow-2xl shadow-blue-600/20 scale-105 z-10'
                  : 'bg-white/5 border-white/10'
              )}
            >
              {pkg.recommended && (
                <div className="absolute -top-3 right-6 bg-blue-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-xl">
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <span className="text-[10px] bg-white/5 border border-white/10 text-white/60 font-mono uppercase tracking-widest px-2.5 py-1 rounded-md">
                  {pkg.type}
                </span>
                <h3 className="text-2xl font-bold mt-4 mb-2">{pkg.name}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{pkg.description}</p>
                
                {/* Timeline badge */}
                <div className="mt-4 p-3 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-white/40 uppercase tracking-widest text-[9px] font-bold">Delivery Timeline</span>
                  <span className="text-blue-400 font-bold uppercase">{pkg.deliveryTime}</span>
                </div>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-black text-white tracking-tighter">£{pkg.price}</span>
                  <span className="text-white/40 text-[10px] uppercase font-black tracking-[0.2em]">One-off build fee</span>
                </div>
              </div>

              <div className="space-y-3 mb-10 flex-grow">
                {pkg.features.map((feature) => (
                  <div key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <span className="text-sm text-white/80 font-medium">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => handleSelect(pkg, monthlyPackages[0])}
                className={cn(
                  'w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 group cursor-pointer',
                  pkg.recommended
                    ? 'bg-blue-600 text-white hover:bg-blue-500 hover:shadow-xl hover:shadow-blue-600/30'
                    : 'bg-white/10 text-white hover:bg-white/20'
                )}
              >
                Start Project Enquiry
              </button>

              <div className="mt-6 flex items-center justify-center gap-2 text-white/20 text-[10px] uppercase font-bold tracking-widest">
                <Info size={12} />
                Requires £20/mo management
              </div>
            </motion.div>
          ))}
        </div>

      <div className="text-center mb-16 pt-10 border-t border-white/5">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl md:text-5xl font-bold mb-6 tracking-tighter uppercase"
        >
          Management <span className="text-white/40 italic">Plans</span>
        </motion.h2>
        <motion.p
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           transition={{ delay: 0.1 }}
           className="text-white/40 text-lg max-w-2xl mx-auto font-medium"
        >
          To ensure security, performance, and reliability, our Essential Management plan is required for all website builds.
        </motion.p>
      </div>

        <div className="grid grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto gap-8 items-stretch">
          {monthlyPackages.map((pkg, idx) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="relative p-8 rounded-3xl bg-white/5 border border-white/10 flex flex-col backdrop-blur-sm"
            >
              <div className="absolute top-6 right-6">
                 {pkg.id === 'essential-care' ? (
                   <span className="px-3 py-1 bg-white/10 text-white/60 text-[10px] font-black uppercase tracking-widest rounded-full">Required Plan</span>
                 ) : (
                   <span className="px-3 py-1 bg-blue-600/20 text-blue-400 border border-blue-500/20 text-[10px] font-black uppercase tracking-widest rounded-full">Optional Upgrade</span>
                 )}
              </div>
              <div className="mb-6 mt-4">
                <h3 className="text-2xl font-bold mb-2 uppercase tracking-tight">{pkg.name}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{pkg.description}</p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-black text-white tracking-tighter">£{pkg.price}</span>
                  <span className="text-white/40 text-[10px] uppercase font-black tracking-[0.2em]">/ Month</span>
                </div>
              </div>

              <div className="space-y-3 flex-grow">
                {pkg.features.map((feature) => (
                  <div key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                    <span className="text-sm text-white/80 font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
