import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Twitter, Github, Linkedin, Instagram } from 'lucide-react';

const footerLinks = [
  {
    title: 'Company',
    links: [
      { name: 'About', path: '/about' },
      { name: 'Portfolio', path: '/portfolio' },
      { name: 'Contact', path: '/contact' },
      { name: 'FAQ', path: '/faq' },
      { name: 'Admin', path: '/admin' },
    ],
  },
  {
    title: 'Services',
    links: [
      { name: 'One-Time Build', path: '/packages' },
      { name: 'Growth Package', path: '/packages' },
      { name: 'Commerce & Custom Hub', path: '/packages' },
      { name: 'Management', path: '/about' },
    ],
  },
  {
    title: 'Legal',
    links: [
      { name: 'Privacy Policy', path: '/privacy' },
      { name: 'Terms of Service', path: '/terms' },
      { name: 'Cookie Policy', path: '/cookies' },
      { name: 'Refund Policy', path: '/refund-policy' },
      { name: 'Disclaimer', path: '/disclaimer' },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-transparent border-t border-white/5 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-20">
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6 group">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-lg italic transition-transform group-hover:scale-110">
                <span className="text-white">S</span>
              </div>
              <span className="text-xl font-bold tracking-tight uppercase">
                SyncSites <span className="text-blue-500">Co.</span>
              </span>
            </Link>
            <p className="text-white/50 max-w-sm mb-8 leading-relaxed">
              We build websites designed to grow your business. High-performance, conversion-optimized digital presence for modern brands.
            </p>
            <div className="flex items-center gap-4">
              {[Twitter, Github, Linkedin, Instagram].map((Icon, idx) => (
                <a
                  key={idx}
                  href="#"
                  className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {footerLinks.map((group) => (
            <div key={group.title}>
              <h4 className="text-sm font-bold uppercase tracking-widest text-white mb-6">
                {group.title}
              </h4>
              <ul className="space-y-4">
                {group.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-white/40 hover:text-white transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/5 pt-10 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="flex flex-wrap justify-center gap-8 lg:gap-12">
            <div className="flex items-center gap-2 text-xs font-medium text-white/30 uppercase tracking-widest">
              <span className="text-blue-500">⚡</span> Fast Global Delivery
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-white/30 uppercase tracking-widest">
              <span className="text-blue-500">📱</span> Mobile-First Optimization
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-white/30 uppercase tracking-widest">
              <span className="text-blue-500">🔒</span> Enterprise-Grade Security
            </div>
          </div>
          
          <div className="text-xs text-white/20 font-mono italic">
            EST. 2024 / SILICON VALLEY STANDARDS / © {new Date().getFullYear()}
          </div>
        </div>
      </div>
    </footer>
  );
}
