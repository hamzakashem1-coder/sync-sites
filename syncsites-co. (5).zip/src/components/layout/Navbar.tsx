import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ClipboardList, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';
import { usePackage } from '../../context/PackageContext';

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'Packages', path: '/packages' },
  { name: 'Portfolio', path: '/portfolio' },
  { name: 'About', path: '/about' },
  { name: 'FAQ', path: '/faq' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { selectedPackage } = usePackage();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <nav
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b',
        scrolled
          ? 'bg-zinc-950/80 backdrop-blur-xl border-white/5 py-4'
          : 'bg-transparent border-transparent py-6'
      )}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl italic shadow-lg shadow-blue-600/20 group-hover:scale-110 transition-transform">
            <span className="text-white">S</span>
          </div>
          <span className="text-xl font-bold tracking-tight uppercase group-hover:text-blue-500 transition-colors">
            SyncSites <span className="text-blue-500">Co.</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                'text-sm font-medium transition-colors hover:text-white',
                location.pathname === link.path ? 'text-white' : 'text-white/60'
              )}
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/contact"
            className="px-5 py-2.5 bg-white text-black rounded-full font-semibold hover:bg-blue-50 transition-all text-sm"
          >
            Start Project
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <Link
            to="/enquiry"
            className="p-2 text-white/60 hover:text-white transition-colors relative"
            title="Review Enquiry Details"
          >
            <ClipboardList size={20} />
            {selectedPackage && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-600 text-white text-[10px] flex items-center justify-center rounded-full animate-pulse">
                1
              </span>
            )}
          </Link>
        </div>

        {/* Mobile Toggle */}
        <div className="flex items-center gap-4 md:hidden">
          <Link to="/enquiry" className="p-2 text-zinc-400 relative" title="Review Enquiry Details">
            <ClipboardList size={20} />
             {selectedPackage && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-blue-600 text-white text-[10px] flex items-center justify-center rounded-full animate-pulse">
                1
              </span>
            )}
          </Link>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 text-zinc-400 hover:text-white"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 right-0 bg-zinc-950 border-b border-zinc-800 p-6 flex flex-col gap-6"
          >
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  'text-lg font-medium transition-colors',
                  location.pathname === link.path ? 'text-blue-400' : 'text-zinc-400'
                )}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/contact"
              className="bg-blue-600 text-white px-6 py-4 rounded-xl text-center font-bold"
            >
              Start Your Website
            </Link>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
