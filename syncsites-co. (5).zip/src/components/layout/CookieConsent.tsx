import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, X, Cookie } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = () => {
    localStorage.setItem('cookie-consent', 'all');
    setIsVisible(false);
  };

  const handleAcceptNecessary = () => {
    localStorage.setItem('cookie-consent', 'necessary');
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-6 left-6 right-6 md:left-auto md:right-6 md:max-w-md z-[100]"
        >
          <div className="bg-[#0a0a0a] border border-white/10 p-6 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 text-blue-500/5 -z-10">
              <Cookie size={120} />
            </div>

            <div className="flex items-start gap-4 mb-6">
              <div className="w-10 h-10 rounded-xl bg-blue-600/10 flex items-center justify-center text-blue-500 shrink-0">
                <ShieldCheck size={20} />
              </div>
              <div>
                <h3 className="text-white font-bold leading-tight mb-1">Cookie Preferences</h3>
                <p className="text-white/40 text-xs leading-relaxed">
                  We use cookies to enhance your experience, analyze site traffic, and serve high-performance advertising. 
                  By clicking "Accept All", you consent to our use of cookies.
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={handleAcceptAll}
                className="w-full py-3 bg-white text-black rounded-xl font-bold text-sm hover:bg-blue-50 transition-all uppercase tracking-tight"
              >
                Accept All
              </button>
              <div className="flex gap-2">
                <button
                  onClick={handleAcceptNecessary}
                  className="flex-1 py-3 bg-white/5 border border-white/10 text-white rounded-xl font-bold text-sm hover:bg-white/10 transition-all uppercase tracking-tight"
                >
                  Necessary Only
                </button>
                <button
                  onClick={() => setShowPreferences(true)}
                  className="px-4 py-3 bg-white/5 border border-white/10 text-white/40 rounded-xl font-bold text-sm hover:text-white transition-all"
                >
                  Settings
                </button>
              </div>
            </div>

            <p className="mt-4 text-[10px] text-white/20 text-center">
              Read our <Link to="/privacy" className="underline hover:text-white">Privacy Policy</Link> for more details.
            </p>
          </div>
        </motion.div>
      )}

      {showPreferences && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-6">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-[#0a0a0a] border border-white/10 p-8 rounded-[2.5rem] max-w-lg w-full relative"
          >
            <button 
              onClick={() => setShowPreferences(false)}
              className="absolute top-6 right-6 text-white/40 hover:text-white"
            >
              <X size={24} />
            </button>

            <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">Cookie Settings</h2>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                <div>
                  <div className="text-sm font-bold text-white uppercase tracking-widest">Necessary</div>
                  <div className="text-[10px] text-white/40">Essential for the website to function. Always active.</div>
                </div>
                <div className="w-10 h-5 bg-blue-600 rounded-full relative">
                  <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 opacity-50">
                <div>
                  <div className="text-sm font-bold text-white uppercase tracking-widest">Analytics</div>
                  <div className="text-[10px] text-white/40">Help us understand how visitors interact with the site.</div>
                </div>
                <div className="w-10 h-5 bg-white/10 rounded-full relative">
                  <div className="absolute left-1 top-1 w-3 h-3 bg-white/20 rounded-full"></div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 opacity-50">
                <div>
                  <div className="text-sm font-bold text-white uppercase tracking-widest">Marketing</div>
                  <div className="text-[10px] text-white/40">Used for targeted advertising and personalization.</div>
                </div>
                <div className="w-10 h-5 bg-white/10 rounded-full relative">
                  <div className="absolute left-1 top-1 w-3 h-3 bg-white/20 rounded-full"></div>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                handleAcceptAll();
                setShowPreferences(false);
              }}
              className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-500 transition-all shadow-[0_0_30px_rgba(37,99,235,0.3)]"
            >
              Save Preferences
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
