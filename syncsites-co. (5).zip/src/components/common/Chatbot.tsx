import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Bot, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

const QUICK_PROMPTS = [
  "Which package is best for SEO?",
  "Can I see some example sites?",
  "What is your setup timeline?",
  "Is hosting included in the monthly?",
  "Do you build custom web apps?",
];

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: "Hello! I am **SyncBot**, your elite partner at **SyncSites Co.**\n\nI can guide you through our one-of-a-kind custom web build packages, SEO strategies, and support plans. How can I accelerate your digital growth today?",
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  const listEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to chat bottom
  const scrollToBottom = () => {
    listEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 100);
    }
  }, [messages, isOpen, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: textToSend };
    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);
    setApiError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          history: messages.concat(userMsg),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data = await response.json();
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.text || "I was unable to retrieve a response from system intelligence. Please try again."
      }]);
    } catch (err: any) {
      console.error("Chat error:", err);
      setApiError("Communication latency detected. Please try sending your prompt again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePromptClick = (promptText: string) => {
    handleSendMessage(promptText);
  };

  const renderMessageContent = (text: string) => {
    // Elegant inline parsing for custom bold text and bullets
    const lines = text.split('\n');
    return lines.map((line, lineIdx) => {
      const isBullet = line.trim().startsWith('-') || line.trim().startsWith('*');
      const content = isBullet ? line.trim().substring(1).trim() : line;

      // Parse bold pattern: **bold text**
      const parts = content.split(/\*\*([^*]+)\*\*/g);

      const formattedContent = parts.map((part, partIdx) => {
        if (partIdx % 2 === 1) {
          return <strong key={partIdx} className="font-extrabold text-blue-400">{part}</strong>;
        }
        return part;
      });

      if (isBullet) {
        return (
          <li key={lineIdx} className="ml-4 list-disc mb-1.5 text-white/90 text-xs md:text-sm">
            {formattedContent}
          </li>
        );
      }

      return (
        <p key={lineIdx} className={cn("text-xs md:text-sm", line.trim() === '' ? 'h-2' : 'mb-2 text-white/90 leading-relaxed')}>
          {formattedContent}
        </p>
      );
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Toggle Button */}
      <motion.button
        id="chatbot-toggle-button"
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "w-14 h-14 rounded-full flex items-center justify-center cursor-pointer shadow-2xl transition-all border outline-none bg-blue-600 hover:bg-blue-500 border-blue-400/40 text-white relative group",
          isOpen ? "bg-zinc-900 border-white/10 hover:bg-zinc-800" : ""
        )}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close-icon"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X size={22} />
            </motion.div>
          ) : (
            <motion.div
              key="chat-icon"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative"
            >
              <MessageSquare size={22} />
              {/* Online pulse dot */}
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] border border-black" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat Window Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="chatbot-msg-window"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: -10, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="absolute bottom-16 right-0 w-[350px] md:w-[400px] h-[550px] bg-zinc-950/95 border border-white/10 rounded-3xl shadow-[0_30px_70px_rgba(0,0,0,0.8)] backdrop-blur-2xl flex flex-col overflow-hidden leading-normal text-white"
          >
            {/* Ambient background glow inside the chat window */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-blue-600/10 rounded-full blur-[40px] pointer-events-none -z-10" />

            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-white/5 bg-white/[0.02]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-blue-500 flex items-center justify-center p-0.5 shadow-md shadow-blue-600/20 relative">
                  <Bot size={20} className="text-white" />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-black" />
                </div>
                <div>
                  <h4 className="text-sm font-black tracking-tight uppercase flex items-center gap-1.5 leading-none mb-1">
                    SyncBot
                    <Sparkles size={11} className="text-blue-500 animate-pulse" />
                  </h4>
                  <p className="text-[9px] font-bold text-emerald-500 tracking-wider uppercase flex items-center gap-1">
                    Partner Success AI
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 bg-white/5 hover:bg-white/10 rounded-xl transition-all text-white/40 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 scrollbar-thin scrollbar-thumb-white/10">
              <AnimatePresence initial={false}>
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className={cn(
                      "flex gap-3 max-w-[85%]",
                      msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
                    )}
                  >
                    {/* Message Bubble */}
                    <div
                      className={cn(
                        "p-4 rounded-3xl",
                        msg.role === 'user'
                          ? "bg-blue-600/95 text-white rounded-tr-sm"
                          : "bg-white/5 border border-white/10 rounded-tl-sm text-white/90"
                      )}
                    >
                      {renderMessageContent(msg.content)}
                    </div>
                  </motion.div>
                ))}

                {/* Loading state indicator */}
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex gap-2 mr-auto items-center"
                  >
                    <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                      <Bot size={14} className="text-blue-500 animate-pulse" />
                    </div>
                    <div className="flex gap-1.5 items-center bg-white/5 border border-white/5 px-4 py-3 rounded-full text-white/40">
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </motion.div>
                )}

                {/* API Error Box */}
                {apiError && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex items-start gap-2 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl text-[11px] font-medium"
                  >
                    <AlertCircle size={14} className="shrink-0 mt-0.5" />
                    <div className="flex-1">
                      {apiError}
                      <button 
                        onClick={() => handleSendMessage(messages[messages.length - 1].content)}
                        className="ml-2 font-bold underline text-white hover:text-blue-200"
                      >
                        Retry
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              <div ref={listEndRef} />
            </div>

            {/* Quick Prompt Pills */}
            <div className="px-5 py-2.5 bg-black/40 border-t border-white/5">
              <div className="text-[8px] font-black uppercase text-white/30 tracking-widest mb-2">Recommended Queries</div>
              <div className="flex flex-wrap gap-2">
                {QUICK_PROMPTS.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handlePromptClick(prompt)}
                    disabled={isLoading}
                    className="px-3 py-1.5 bg-white/5 hover:bg-blue-600/25 border border-white/5 hover:border-blue-500/50 rounded-full text-[10px] text-white/50 hover:text-blue-300 transition-all font-bold tracking-tight text-left disabled:opacity-50 disabled:pointer-events-none"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form area */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputMessage);
              }}
              className="p-4 border-t border-white/5 bg-white/[0.01] flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Message SyncBot..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                disabled={isLoading}
                className="flex-grow bg-white/5 border border-white/15 hover:border-white/20 focus:border-blue-500 rounded-2xl px-4 py-3 text-xs focus:outline-none placeholder-white/30 text-white transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isLoading}
                className="w-10 h-10 rounded-2xl bg-blue-600 border border-blue-400/20 flex items-center justify-center shrink-0 cursor-pointer text-white disabled:bg-white/5 disabled:border-white/5 disabled:text-white/20 hover:bg-blue-500 transition-all shadow-md shadow-blue-600/10 disabled:shadow-none"
              >
                <Send size={15} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
