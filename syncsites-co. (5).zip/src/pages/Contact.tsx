import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import { Mail, Phone, MessageSquare, Send, CheckCircle2, Loader2 } from 'lucide-react';
import { useState, FormEvent } from 'react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Growth Package Inquiry',
    message: ''
  });

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // 1. Save to Firestore
      const leadsRef = collection(db, 'leads');
      await addDoc(leadsRef, {
        ...formData,
        status: 'new',
        createdAt: serverTimestamp(),
      });

      // 2. Call backend for email notification
      try {
        await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData),
        });
      } catch (err) {
        console.warn('Backend notification failed, but lead was saved to Firestore.');
      }

      setSubmitted(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'leads');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen relative overflow-hidden"
    >
        <Meta 
            title="Contact Us | SyncSites Co. Strategy Team" 
            description="Ready to scale? Connect with our growth specialists today for a professional consultation and custom web strategy."
        />
        <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
                {/* Information Col */}
                <div className="lg:col-span-5">
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        animate={{ opacity: 1, x: 0 }}
                    >
                        <div className="text-blue-500 font-bold uppercase tracking-widest text-[10px] mb-6">Let's Talk Business</div>
                        <h1 className="text-5xl md:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
                           Start Your <br />
                           <span className="text-white/40 italic">Transformation.</span>
                        </h1>
                        <p className="text-white/40 text-xl mb-12 leading-relaxed">
                           Ready to stop losing customers and start growing? Leave a message, and our strategy team will reach out to schedule a consultation.
                        </p>

                        <div className="space-y-8">
                            <div className="flex items-center gap-6 group cursor-pointer">
                                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all">
                                    <Mail size={24} />
                                </div>
                                <div>
                                    <div className="text-white/20 text-[10px] font-bold uppercase tracking-widest mb-1">Email Us</div>
                                    <div className="text-xl font-bold text-white tracking-tight uppercase">hello@syncsites.co</div>
                                </div>
                            </div>
                            <div className="flex items-center gap-6 group cursor-pointer">
                                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all">
                                    <Phone size={24} />
                                </div>
                                <div>
                                    <div className="text-white/20 text-[10px] font-bold uppercase tracking-widest mb-1">Call Us</div>
                                    <div className="text-xl font-bold text-white tracking-tight uppercase">+44 20 1234 5678</div>
                                </div>
                            </div>
                             <div className="flex items-center gap-6 group cursor-pointer">
                                <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all">
                                    <MessageSquare size={24} />
                                </div>
                                <div>
                                    <div className="text-white/20 text-[10px] font-bold uppercase tracking-widest mb-1">Live Chat</div>
                                    <div className="text-xl font-bold text-white tracking-tight uppercase text-sm">Available 9am - 5pm GMT</div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>

                {/* Form Col */}
                <div className="lg:col-span-7">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-12 rounded-3xl bg-white/5 border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-sm"
                    >
                        {submitted ? (
                            <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="text-center py-10"
                            >
                                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-xl shadow-blue-600/20">
                                   <CheckCircle2 size={32} className="text-white" />
                                </div>
                                <h3 className="text-3xl font-bold mb-4 uppercase tracking-tighter">Message Received</h3>
                                <p className="text-white/40 max-w-sm mx-auto">Thank you for reaching out. A growth specialist will be in touch with you within 24 business hours.</p>
                                <button
                                    onClick={() => {
                                      setSubmitted(false);
                                      setFormData({ name: '', email: '', subject: 'Growth Package Inquiry', message: '' });
                                    }}
                                    className="mt-8 text-blue-500 font-bold hover:underline uppercase text-xs tracking-widest"
                                >
                                    Send another message
                                </button>
                            </motion.div>
                        ) : (
                            <form onSubmit={handleSubmit} className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-3">
                                        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Full Name</label>
                                        <input
                                            required
                                            type="text"
                                            placeholder="John Doe"
                                            value={formData.name}
                                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-medium"
                                        />
                                    </div>
                                    <div className="space-y-3">
                                        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Email Address</label>
                                        <input
                                            required
                                            type="email"
                                            placeholder="john@example.com"
                                            value={formData.email}
                                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-medium"
                                        />
                                    </div>
                                </div>
                                <div className="space-y-3">
                                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Subject</label>
                                    <select 
                                        value={formData.subject}
                                        onChange={(e) => setFormData({...formData, subject: e.target.value})}
                                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-medium appearance-none"
                                    >
                                        <option className="bg-zinc-950 text-white">Growth Package Inquiry</option>
                                        <option className="bg-zinc-950 text-white">One-Time Build Inquiry</option>
                                        <option className="bg-zinc-950 text-white">Full Custom Commerce Inquiry</option>
                                        <option className="bg-zinc-950 text-white">Custom Enterprise Solution</option>
                                        <option className="bg-zinc-950 text-white">General Support</option>
                                    </select>
                                </div>
                                <div className="space-y-3">
                                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Your Message</label>
                                    <textarea
                                        required
                                        rows={5}
                                        placeholder="Tell us about your business goals..."
                                        value={formData.message}
                                        onChange={(e) => setFormData({...formData, message: e.target.value})}
                                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-blue-500 focus:bg-white/10 transition-all font-medium"
                                    ></textarea>
                                </div>
                                <button
                                    type="submit"
                                    disabled={loading}
                                    className="w-full py-5 bg-white text-black rounded-2xl font-bold text-lg hover:bg-blue-50 hover:scale-[1.01] disabled:opacity-50 disabled:scale-100 transition-all flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(37,99,235,0.2)]"
                                >
                                    {loading ? (
                                      <Loader2 className="animate-spin" size={24} />
                                    ) : (
                                      <>
                                        Send Message
                                        <Send size={18} />
                                      </>
                                    )}
                                </button>
                                <p className="text-center text-white/20 text-[10px] uppercase font-bold tracking-[0.1em]">
                                    By submitting this form, you agree to our Privacy Policy.
                                </p>
                            </form>
                        )}
                    </motion.div>
                </div>
            </div>
        </div>
    </motion.div>
  );
}
