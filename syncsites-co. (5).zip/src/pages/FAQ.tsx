import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import FAQSection from '../components/Home/FAQSection';
import FinalCTA from '../components/Home/FinalCTA';

export default function FAQ() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-20"
    >
        <Meta 
            title="FAQ | Support & Knowledge Base | SyncSites Co." 
            description="Got questions about your next website? Explore our comprehensive FAQ covering pricing, SEO, design process, and ongoing support."
        />
        <div className="py-24 px-6 text-center overflow-hidden relative">
             <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="max-w-4xl mx-auto"
             >
                <div className="text-blue-500 font-bold uppercase tracking-widest text-[10px] mb-6">Support & Information</div>
                <h1 className="text-5xl md:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
                   Common <br />
                   <span className="text-white/40 italic">Inquiries.</span>
                </h1>
                <p className="text-white/40 text-xl max-w-2xl mx-auto">
                   Everything you need to know about our process, pricing, and how we help your business succeed.
                </p>
             </motion.div>
        </div>

        <FAQSection />

        <div className="py-24 bg-zinc-950 px-6">
            <div className="max-w-4xl mx-auto text-center p-12 rounded-[3.5rem] bg-zinc-900/50 border border-zinc-800">
                <h3 className="text-2xl font-bold mb-4 italic">Still have questions?</h3>
                <p className="text-zinc-500 mb-8">If you can't find the answer you're looking for, our team is always ready to help.</p>
                <button className="text-blue-500 font-bold hover:underline underline-offset-8">Contact Our Strategy Team</button>
            </div>
        </div>

        <FinalCTA />
    </motion.div>
  );
}
