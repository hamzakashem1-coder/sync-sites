import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import PortfolioSection from '../components/Home/PortfolioSection';
import FinalCTA from '../components/Home/FinalCTA';

export default function Portfolio() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-20"
    >
        <Meta 
            title="Example Concepts | SyncSites Co." 
            description="Explore our example website concepts demonstrating the style and quality SyncSites Co. can create."
        />
        <div className="py-24 px-6 text-center overflow-hidden relative">
             <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto"
             >
                <div className="text-blue-500 font-bold uppercase tracking-widest text-[10px] mb-6">Demonstration Designs</div>
                <h1 className="text-5xl md:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
                   Example Website <br />
                   <span className="text-white/40 italic">Concepts</span>
                </h1>
                <p className="text-white/40 text-xl max-w-2xl mx-auto">
                   These are example concepts demonstrating the style, quality, and technical standard of websites SyncSites Co. can create for your business.
                </p>
             </motion.div>
        </div>

        <PortfolioSection />

        <div className="py-24 px-6">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
               {[
                 { title: 'Innovation', desc: 'Pushing boundaries of what represents a modern business online.' },
                 { title: 'Performance', desc: 'Lightning fast load times that outrun the competition.' },
                 { title: 'Precision', desc: 'Attention to detail that separates elite brands from the rest.' },
               ].map((item, i) => (
                  <div key={i} className="p-10 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm">
                     <h3 className="text-xl font-bold mb-4 tracking-tight uppercase">{item.title}</h3>
                     <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
                  </div>
               ))}
            </div>
        </div>

        <FinalCTA />
    </motion.div>
  );
}
