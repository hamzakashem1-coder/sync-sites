import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import Hero from '../components/Home/Hero';
import ProblemSection from '../components/Home/ProblemSection';
import GrowthSection from '../components/Home/GrowthSection';
import ServicesSection from '../components/Home/ServicesSection';
import PortfolioSection from '../components/Home/PortfolioSection';
import WhyChooseSection from '../components/Home/WhyChooseSection';
import PackagesSection from '../components/Home/PackagesSection';
import ProcessSection from '../components/Home/ProcessSection';
import TestimonialsSection from '../components/Home/TestimonialsSection';
import FAQSection from '../components/Home/FAQSection';
import FinalCTA from '../components/Home/FinalCTA';

export default function Home() {
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Meta 
        title="SyncSites Co. | High-Performance Business Web Solutions"
        description="We build enterprise-grade websites that drive growth. Premium design, conversion psychology, and total management for ambitious brands."
      />
      <Hero />
      <ProblemSection />
      <GrowthSection />
      <ServicesSection />
      <PortfolioSection />
      <WhyChooseSection />
      <PackagesSection />
      <ProcessSection />
      <TestimonialsSection />
      <FAQSection />
      <FinalCTA />
    </motion.main>
  );
}
