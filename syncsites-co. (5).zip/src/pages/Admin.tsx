import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import Meta from '../components/common/Meta';
import { db, auth, googleProvider } from '../lib/firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { useState, useEffect } from 'react';
import { LayoutDashboard, Users, Package, MessageCircle, LogOut, Search, Clock, CheckCircle2, XCircle, Trash2 } from 'lucide-react';
import { cn } from '../lib/utils';

// Hardcoded for the instruction context but in reality would be in Firestore admins collection
const ALLOWED_ADMINS = ['hamzakashem1@gmail.com'];

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: any, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
}

function StatusItem({ label, active }: { label: string; active: boolean }) {
  return (
    <div className="flex items-center justify-between group">
      <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest">{label}</span>
      <div className={cn("w-2 h-2 rounded-full", active ? "bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]" : "bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.5)]")} />
    </div>
  );
}

function StatCard({ label, value, icon: Icon, trend }: { label: string; value: string; icon: any; trend?: string }) {
  return (
    <div className="p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-md relative overflow-hidden group hover:bg-white/10 transition-all">
       <div className="absolute top-[-20%] right-[-10%] w-32 h-32 bg-blue-600/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
       <div className="flex items-start justify-between relative z-10 mb-6">
          <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-white/40 group-hover:bg-blue-600 group-hover:text-white transition-all">
             <Icon size={20} />
          </div>
          {trend && (
            <span className="text-[8px] font-black uppercase text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full tracking-widest">
              {trend}
            </span>
          )}
       </div>
       <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] mb-1">{label}</div>
       <div className="text-3xl font-bold tracking-tighter italic">{value}</div>
    </div>
  );
}

export default function Admin() {
    const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [packageEnquiries, setPackageEnquiries] = useState<any[]>([]);
  const [generalEnquiries, setGeneralEnquiries] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'packages' | 'general' | 'bin'>('packages');
  const [configStatus, setConfigStatus] = useState({ stripe: false, resend: false, webhook: false });
  const [searchQuery, setSearchQuery] = useState('');
  const [monthFilter, setMonthFilter] = useState<string>('all');
  const [todos, setTodos] = useState<{id: string, text: string, done: boolean}[]>([]);
  const [newTodo, setNewTodo] = useState('');
  
  // Enterprise Security States
  const [passcode, setPasscode] = useState('');
  const [twoFactor, setTwoFactor] = useState('');
  const [authStage, setAuthStage] = useState<'google' | 'secure_challenge' | 'granted'>('google');
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [lockoutTime, setLockoutTime] = useState<number | null>(null);
  const [secError, setSecError] = useState('');

  // Local storage lockout checks
  useEffect(() => {
    const savedTodos = localStorage.getItem('admin_todos');
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
    
    const lockedUntil = localStorage.getItem('admin_lockout_until');
    if (lockedUntil) {
      const remaining = Number(lockedUntil) - Date.now();
      if (remaining > 0) {
        setLockoutTime(Number(lockedUntil));
        setSecError('Brute-force security lockdown active.');
        const interval = setInterval(() => {
          const rem = Number(lockedUntil) - Date.now();
          if (rem <= 0) {
            setLockoutTime(null);
            setSecError('');
            localStorage.removeItem('admin_lockout_until');
            clearInterval(interval);
          }
        }, 1000);
        return () => clearInterval(interval);
      } else {
        localStorage.removeItem('admin_lockout_until');
      }
    }
  }, []);

  const getTimestampMs = (item: any) => {
    if (!item) return 0;
    if (item.createdAt) {
      if (typeof item.createdAt.toMillis === 'function') {
        const ms = item.createdAt.toMillis();
        return isNaN(ms) ? 0 : ms;
      }
      if (item.createdAt.seconds !== undefined) {
        return item.createdAt.seconds * 1000;
      }
      const t = new Date(item.createdAt);
      return isNaN(t.getTime()) ? 0 : t.getTime();
    }
    if (item.updatedAt) {
      if (typeof item.updatedAt.toMillis === 'function') {
        const ms = item.updatedAt.toMillis();
        return isNaN(ms) ? 0 : ms;
      }
      if (item.updatedAt.seconds !== undefined) {
        return item.updatedAt.seconds * 1000;
      }
      const t = new Date(item.updatedAt);
      return isNaN(t.getTime()) ? 0 : t.getTime();
    }
    return 0;
  };

  const formatTime = (item: any) => {
    const ms = getTimestampMs(item);
    if (!ms) return 'JUST NOW';
    const date = new Date(ms);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDateLabel = (item: any) => {
    const ms = getTimestampMs(item);
    if (!ms) return 'JUST NOW';
    const date = new Date(ms);
    return date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const isMatchingMonth = (item: any) => {
    if (monthFilter === 'all') return true;
    const ms = getTimestampMs(item);
    if (!ms) return false;
    const date = new Date(ms);
    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    return monthKey === monthFilter;
  };

  const monthFilteredPackages = packageEnquiries.filter(isMatchingMonth);
  const monthFilteredGeneral = generalEnquiries.filter(isMatchingMonth);

  const totalExpectedRevenue = monthFilteredPackages.filter(l => l.status !== 'bin').reduce((acc, curr) => acc + (Number(curr.price) || 0), 0);
  const totalCompletedRevenue = monthFilteredPackages.filter(l => l.status === 'completed').reduce((acc, curr) => acc + (Number(curr.price) || 0), 0);
  const totalMonthlyMgt = monthFilteredPackages.filter(l => l.status !== 'bin').reduce((acc, curr) => acc + (Number(curr.monthlyFee) || 0), 0);

  const stats = {
    totalEnquiries: monthFilteredPackages.filter(l => l.status !== 'bin').length + monthFilteredGeneral.filter(l => l.status !== 'bin').length,
    openEnquiries: monthFilteredPackages.filter(l => l.status === 'pending').length + monthFilteredGeneral.filter(l => l.status === 'new').length,
    activeProjects: monthFilteredPackages.filter(l => l.status === 'processing').length,
    expectedRevenue: totalExpectedRevenue,
    completedRevenue: totalCompletedRevenue,
    monthlyRevenue: totalMonthlyMgt,
  };

  const filteredPackages = monthFilteredPackages.filter(o => {
    if (activeTab === 'bin' && o.status !== 'bin') return false;
    if (activeTab === 'packages' && o.status === 'bin') return false;
    if (activeTab === 'general') return false;
    const q = searchQuery.toLowerCase();
    return (
      (o.customerName?.toLowerCase().includes(q) ||
      o.packageName?.toLowerCase().includes(q) ||
      o.email?.toLowerCase().includes(q) ||
      o.phone?.includes(q) ||
      o.businessName?.toLowerCase().includes(q) ||
      false)
    );
  });

  const filteredGeneral = monthFilteredGeneral.filter(l => {
    if (activeTab === 'bin' && l.status !== 'bin') return false;
    if (activeTab === 'general' && l.status === 'bin') return false;
    if (activeTab === 'packages') return false;
    const q = searchQuery.toLowerCase();
    return (
      (l.name?.toLowerCase().includes(q) ||
      l.email?.toLowerCase().includes(q) ||
      l.message?.toLowerCase().includes(q) ||
      false)
    );
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u && ALLOWED_ADMINS.includes(u.email || '')) {
         setAuthStage('secure_challenge');
      } else {
         setAuthStage('google');
      }
    });
    return unsubscribe;
  }, []);

  const verifyChallenge = () => {
    setSecError('');
    if (lockoutTime && Date.now() < lockoutTime) {
      setSecError('Multiple authentications failed. Form sequence is frozen.');
      return;
    }

    if (!passcode || !twoFactor) {
      setSecError('Ensure both security parameters are specified.');
      return;
    }

    if (passcode === 'SYNC-CORE-2026' && twoFactor === '992811') {
      setAuthStage('granted');
      setLoginAttempts(0);
      setSecError('');
    } else {
      const nextAttempts = loginAttempts + 1;
      setLoginAttempts(nextAttempts);
      if (nextAttempts >= 5) {
        const lockUntil = Date.now() + 15 * 60 * 1000; // 15 mins lock
        setLockoutTime(lockUntil);
        localStorage.setItem('admin_lockout_until', String(lockUntil));
        setSecError('Too many failed authorization attempts. System locked for 15 mins.');
      } else {
        setSecError(`Access key invalid. Attempt ${nextAttempts}/5. consecutive fails will lock down.`);
      }
    }
  };

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const res = await fetch('/api/admin/config-status');
        const data = await res.json();
        setConfigStatus(data);
      } catch (err) {
        console.error('Failed to fetch config status', err);
      }
    };
    if (user && ALLOWED_ADMINS.includes(user.email || '')) {
      fetchConfig();
    }
  }, [user]);

  useEffect(() => {
    if (user && ALLOWED_ADMINS.includes(user.email || '')) {
      const qLeads = query(collection(db, 'leads'), orderBy('createdAt', 'desc'));
      const qOrders = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));

      const unsubLeads = onSnapshot(qLeads, (snap) => {
        setGeneralEnquiries(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'leads');
      });

      const unsubOrders = onSnapshot(qOrders, (snap) => {
        setPackageEnquiries(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'orders');
      });

      return () => {
        unsubLeads();
        unsubOrders();
      };
    }
  }, [user]);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => signOut(auth);

  const updateStatus = async (col: string, id: string, newStatus: string) => {
    const path = `${col}/${id}`;
    try {
      const docRef = doc(db, col, id);
      await updateDoc(docRef, { status: newStatus, updatedAt: new Date() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const deleteRecord = async (col: string, id: string) => {
    const path = `${col}/${id}`;
    if (window.confirm('Delete this record forever?')) {
      try {
        await deleteDoc(doc(db, col, id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, path);
      }
    }
  };

  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center text-white/20">Initialising Core...</div>;

  if (!user || !ALLOWED_ADMINS.includes(user.email || '')) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
        <Meta title="Admin Access | SyncSites Co." />
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="max-w-md w-full p-12 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl"
        >
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-blue-600/30">
             <LayoutDashboard size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-4 uppercase tracking-tighter italic text-white">Admin Portal</h1>
          <p className="text-white/40 mb-10">This restricted area is for authorised growth partners only. Please authenticate to continue.</p>
          <button
            onClick={handleLogin}
            className="w-full py-4 bg-white text-black rounded-xl font-bold hover:bg-blue-50 transition-all flex items-center justify-center gap-3 uppercase tracking-tight"
          >
            Authenticate with Google
          </button>
          {user && (
            <button
              onClick={handleLogout}
              className="mt-4 w-full py-3 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 rounded-xl font-bold transition-all flex items-center justify-center gap-3 uppercase tracking-tight text-xs"
            >
              Sign Out & Switch Account
            </button>
          )}
          {!user && <p className="mt-6 text-[10px] text-white/20 uppercase font-black tracking-widest leading-relaxed">System protected by 256-bit encryption & Firebase Auth</p>}
          {user && <p className="mt-6 text-[10px] text-rose-500 uppercase font-black tracking-widest leading-relaxed underline">Access Denied for {user.email}</p>}
        </motion.div>
      </div>
    );
  }

  if (authStage !== 'granted') {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
        <Meta title="Console Security Challenge | SyncSites Co." />
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="max-w-md w-full p-12 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl text-left font-sans"
        >
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-8 shadow-2xl shadow-blue-600/30">
             <LayoutDashboard size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-2 uppercase tracking-tighter italic text-white">Security 2FA</h1>
          <p className="text-white/40 mb-8 text-xs leading-relaxed font-sans">
            Welcome, <span className="text-blue-400 font-bold">{user.displayName || user.email}</span>. A secondary identification challenge is required for SyncCore command access.
          </p>

          <div className="space-y-5">
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-white/30 block mb-2">OPERATOR ACCESS PASSCODE</label>
              <input 
                type="password" 
                placeholder="••••••••••••••" 
                value={passcode}
                disabled={!!lockoutTime && Date.now() < lockoutTime}
                onChange={(e) => setPasscode(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-sm font-mono tracking-widest focus:outline-none focus:border-blue-500/50 text-white"
              />
            </div>

            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-white/30 block mb-2">2FA SECURITY TOKEN (6-DIGITS)</label>
              <input 
                type="text" 
                maxLength={6}
                placeholder="      ••••••" 
                value={twoFactor}
                disabled={!!lockoutTime && Date.now() < lockoutTime}
                onChange={(e) => setTwoFactor(e.target.value.replace(/\D/g, ''))}
                className="w-full bg-white/5 border border-white/15 rounded-xl px-4 py-3.5 text-center text-lg font-mono tracking-[0.25em] focus:outline-none focus:border-blue-500/50 text-white"
              />
              <span className="text-[8px] font-bold text-white/20 uppercase tracking-wider block mt-1.5 leading-relaxed font-sans">
                Check secure offline authenticator token key.
              </span>
            </div>

            {secError && (
              <p className="text-xs text-rose-500 font-bold leading-relaxed border border-rose-500/10 bg-rose-500/5 p-3 rounded-xl font-sans">
                {secError}
              </p>
            )}

            <button
              onClick={verifyChallenge}
              disabled={!!lockoutTime && Date.now() < lockoutTime}
              className="mt-4 w-full py-4 bg-white text-black hover:bg-blue-500 hover:text-white disabled:bg-white/10 disabled:text-white/20 rounded-xl font-bold transition-all flex items-center justify-center gap-2 uppercase tracking-tight text-sm font-sans"
            >
              Verify & Unlock Console
            </button>

            <button
              onClick={handleLogout}
              className="w-full py-3 bg-white/5 hover:bg-rose-500/20 text-white/60 hover:text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2 uppercase tracking-tight text-xs border border-white/5 font-sans"
            >
              Sign Out & Switch Operator
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex text-white font-sans overflow-hidden">
      <Meta title="SyncSites | Command Center" />
      
      {/* Sidebar */}
      <aside className="w-72 border-r border-white/10 bg-white/5 backdrop-blur-xl flex flex-col pt-12 pb-8 px-6 sticky top-0 h-screen z-50">
          <Link to="/" className="flex items-center gap-2 mb-12 group px-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-lg italic transition-transform group-hover:scale-110">
              <span className="text-white">S</span>
            </div>
            <span className="text-xl font-black tracking-tight uppercase italic">Sync<span className="text-blue-500">Core</span></span>
          </Link>

          <div className="mb-12">
             <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] mb-6 px-2">Main Dashboard</div>
             <nav className="space-y-2">
                <button 
                  onClick={() => setActiveTab('packages')}
                  className={cn("w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all uppercase text-[10px] tracking-widest", activeTab === 'packages' ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]" : "text-white/40 hover:text-white hover:bg-white/5")}
                >
                  <Package size={16} />
                  Project Enquiries <span className="ml-auto opacity-40">{packageEnquiries.filter(e => e.status !== 'bin').length}</span>
                </button>
                <button 
                  onClick={() => setActiveTab('general')}
                  className={cn("w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all uppercase text-[10px] tracking-widest", activeTab === 'general' ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]" : "text-white/40 hover:text-white hover:bg-white/5")}
                >
                  <MessageCircle size={16} />
                  General Contact <span className="ml-auto opacity-40">{generalEnquiries.filter(e => e.status !== 'bin').length}</span>
                </button>
                <button 
                  onClick={() => setActiveTab('bin')}
                  className={cn("w-full flex items-center gap-4 px-4 py-3 rounded-xl font-bold transition-all uppercase text-[10px] tracking-widest", activeTab === 'bin' ? "bg-red-500/20 text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.1)]" : "text-white/40 hover:text-rose-500 hover:bg-rose-500/10")}
                >
                  <Trash2 size={16} />
                  Recycle Bin <span className="ml-auto opacity-40">{packageEnquiries.filter(e => e.status === 'bin').length + generalEnquiries.filter(e => e.status === 'bin').length}</span>
                </button>
             </nav>
          </div>

          <div>
             <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] mb-6 px-2">Integrations</div>
             <div className="space-y-5 px-4 bg-white/5 p-6 rounded-2xl border border-white/10 border-dashed">
                <StatusItem label="Stripe API" active={configStatus.stripe} />
                <StatusItem label="Resend Server" active={configStatus.resend} />
                <StatusItem label="Webhook listener" active={configStatus.webhook} />
             </div>
          </div>

          <div className="mt-auto">
             <button 
               onClick={handleLogout}
               className="w-full flex items-center gap-4 px-4 py-4 rounded-xl font-bold text-rose-500 hover:bg-rose-500/10 transition-all uppercase text-[10px] tracking-widest"
             >
               <LogOut size={16} />
               Secure Logout
             </button>
          </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-[radial-gradient(circle_at_top_right,rgba(37,99,235,0.05),transparent_50%)]">
          <div className="max-w-7xl mx-auto px-12 pt-16 pb-24">
             {/* Header */}
             <div className="flex justify-between items-start mb-16">
                <div>
                   <h1 className="text-5xl font-black mb-4 uppercase tracking-[ -0.05em] leading-none italic">
                     Console <span className="text-white/20">A.01</span>
                   </h1>
                   <div className="flex items-center gap-6 text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">
                      <div className="flex items-center gap-2">
                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                         Local Node: Active
                      </div>
                      <div className="w-[1px] h-4 bg-white/10" />
                      <span>Operator: {user.displayName}</span>
                      <div className="w-[1px] h-4 bg-white/10" />
                      <span>Region: EU-WEST-1</span>
                   </div>
                </div>
                
                <div className="flex items-center gap-4">
                   <select
                      value={monthFilter}
                      onChange={(e) => setMonthFilter(e.target.value)}
                      className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-[10px] font-bold uppercase tracking-widest focus:outline-none focus:border-blue-500/50 transition-all text-white/60"
                   >
                      <option value="all">ALL TIME</option>
                      {/* Generate last 6 months */}
                      {Array.from({ length: 6 }).map((_, i) => {
                         const d = new Date();
                         d.setMonth(d.getMonth() - i);
                         const val = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
                         const label = d.toLocaleDateString([], { month: 'long', year: 'numeric' });
                         return <option key={val} value={val}>{label}</option>;
                      })}
                   </select>

                   <div className="relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                      <input 
                        type="text" 
                        placeholder="SEARCH DATA..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-white/5 border border-white/10 rounded-xl px-12 py-3 text-[10px] font-bold uppercase tracking-widest focus:outline-none focus:border-blue-500/50 w-64 transition-all"
                      />
                   </div>
                </div>
             </div>

             {/* Stats Bar */}
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                <StatCard label="Pipeline Expected Value" value={`£${stats.expectedRevenue.toLocaleString()}`} icon={Package} trend="Pipeline" />
                <StatCard label="Completed Revenue" value={`£${stats.completedRevenue.toLocaleString()}`} icon={CheckCircle2} trend="Realised" />
                <StatCard label="Contracted Monthly Revenue" value={`£${stats.monthlyRevenue.toLocaleString()}/mo`} icon={Clock} trend="Recurring" />
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
                <StatCard label="Total Enquiries" value={String(stats.totalEnquiries)} icon={Package} />
                <StatCard label="Open / Unread" value={String(stats.openEnquiries)} icon={Users} trend="Action Req." />
                <StatCard label="In Progress" value={String(stats.activeProjects)} icon={Clock} />
                <StatCard label="General Contact" value={String(generalEnquiries.filter(e => e.status !== 'bin').length)} icon={MessageCircle} />
             </div>

             {/* Dynamic Content */}
             <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
                {/* Main List */}
                <div className="xl:col-span-3 space-y-6">
                   <div className="flex items-center justify-between mb-8">
                      <h2 className="text-2xl font-bold uppercase tracking-tighter italic">
                        {activeTab === 'packages' ? 'Project Enquiries' : activeTab === 'general' ? 'General Contact' : 'Recycle Bin'}
                      </h2>
                      <div className="text-[10px] font-black text-white/20 uppercase tracking-widest flex items-center gap-6">
                        <span>Displaying {activeTab === 'packages' ? filteredPackages.length : activeTab === 'general' ? filteredGeneral.length : filteredPackages.length + filteredGeneral.length} results</span>
                        <div className="flex items-center gap-1">
                           <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                           Syncing
                        </div>
                      </div>
                   </div>

                    <motion.div
                      key={activeTab + searchQuery}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      {(activeTab === 'packages' || activeTab === 'bin') && (
                        <>
                          {filteredPackages.length === 0 && activeTab === 'packages' && <div className="p-32 text-center text-white/10 font-bold uppercase tracking-[0.3em] border border-dashed border-white/5 rounded-[40px]">Accessing empty directory...</div>}
                          {filteredPackages.map(order => (
                            <div key={order.id} className="p-8 rounded-[32px] bg-white/5 border border-white/10 flex flex-col xl:flex-row xl:items-center justify-between gap-6 group hover:bg-white/[0.08] transition-all relative overflow-hidden backdrop-blur-sm">
                              <div className="flex flex-col sm:flex-row sm:items-start gap-6 relative z-10 flex-1">
                                <div className="w-16 h-16 bg-blue-600/10 rounded-2xl flex items-center justify-center text-blue-500 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-xl shadow-blue-600/0 group-hover:shadow-blue-600/20 shrink-0">
                                   <Package size={24} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex flex-wrap items-center gap-3 mb-2">
                                     <h3 className="text-xl font-black tracking-tight leading-none italic uppercase">{order.packageName}</h3>
                                     <span className={cn("text-[8px] font-black uppercase px-2 py-1 rounded-full tracking-widest", 
                                       order.status === 'completed' ? "bg-emerald-500 text-black" : 
                                       order.status === 'pending' ? "bg-amber-500 text-black" : 
                                       order.status === 'bin' ? "bg-rose-500 text-white" : "bg-white/10 text-white/60"
                                     )}>{order.status}</span>
                                  </div>
                                  <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest flex flex-wrap items-center gap-x-4 gap-y-1.5 mt-2">
                                     <span>{order.customerName}</span>
                                     <span className="w-1 h-1 rounded-full bg-white/10" />
                                     <span className="text-blue-400 font-bold lowercase">{order.email}</span>
                                     {order.phone && (
                                       <>
                                         <span className="w-1 h-1 rounded-full bg-white/10" />
                                         <span className="text-white/80">{order.phone}</span>
                                       </>
                                     )}
                                     <span className="w-1 h-1 rounded-full bg-white/10" />
                                     <span className="text-white/60">{order.businessName}</span>
                                     <span className="w-1 h-1 rounded-full bg-white/10" />
                                     <span className="text-blue-500 font-black">
                                       £{Number(order.price || 0).toLocaleString()}
                                       {order.monthlyFee ? ` + £${Number(order.monthlyFee).toLocaleString()}/mo` : ''}
                                     </span>
                                     {order.createdAt && (
                                       <>
                                         <span className="w-1 h-1 rounded-full bg-white/10" />
                                         <span className="text-white/30">{formatDateLabel(order)} {formatTime(order)}</span>
                                       </>
                                     )}
                                  </div>
                                  {order.notes && (
                                    <div className="mt-3 text-[11px] font-medium text-white/60 bg-white/5 py-2.5 px-4 rounded-xl border border-white/5 whitespace-pre-wrap">
                                       <span className="text-blue-400 font-bold uppercase text-[9px] tracking-wider block mb-1">Project Brief / Notes:</span>
                                       <span className="italic">"{order.notes}"</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-3 opacity-100 xl:opacity-0 group-hover:opacity-100 transition-all xl:translate-x-4 group-hover:translate-x-0 shrink-0">
                                 {activeTab === 'bin' ? (
                                   <>
                                     <button onClick={() => updateStatus('orders', order.id, 'pending')} title="Restore" className="p-4 bg-white/5 hover:bg-emerald-500 hover:text-black rounded-2xl text-white/40 transition-all shadow-xl">Restore</button>
                                     <button onClick={() => deleteRecord('orders', order.id)} title="Delete Forever" className="p-4 bg-white/5 hover:bg-rose-500 hover:text-white rounded-2xl text-white/40 transition-all shadow-xl"><Trash2 size={16} /></button>
                                   </>
                                 ) : (
                                   <>
                                     <button onClick={() => updateStatus('orders', order.id, 'processing')} title="Mark as Processing" className="p-4 bg-white/5 hover:bg-blue-600 hover:text-white rounded-2xl text-white/40 transition-all shadow-xl"><Clock size={16} /></button>
                                     <button onClick={() => updateStatus('orders', order.id, 'completed')} title="Mark as Completed" className="p-4 bg-white/5 hover:bg-emerald-500 hover:text-black rounded-2xl text-white/40 transition-all shadow-xl"><CheckCircle2 size={16} /></button>
                                     <button onClick={() => updateStatus('orders', order.id, 'bin')} title="Move to Bin" className="p-4 bg-white/5 hover:bg-rose-500 hover:text-white rounded-2xl text-white/40 transition-all shadow-xl"><Trash2 size={16} /></button>
                                   </>
                                 )}
                              </div>
                            </div>
                          ))}
                        </>
                      )}
                      
                      {(activeTab === 'general' || activeTab === 'bin') && (
                        <>
                          {filteredGeneral.length === 0 && activeTab === 'general' && <div className="p-32 text-center text-white/10 font-bold uppercase tracking-[0.3em] border border-dashed border-white/5 rounded-[40px]">No transmission found...</div>}
                          {filteredGeneral.map(lead => (
                            <div key={lead.id} className="p-8 sm:p-10 rounded-[32px] bg-white/5 border border-white/10 hover:bg-white/[0.08] transition-all group backdrop-blur-sm relative overflow-hidden">
                               <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-8 relative z-10">
                                  <div className="flex items-center gap-6 min-w-0">
                                     <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center text-white/20 group-hover:bg-blue-600 transition-all group-hover:text-white group-hover:shadow-[0_0_20px_rgba(37,99,235,0.3)] shrink-0">
                                        <Users size={24} />
                                     </div>
                                     <div className="min-w-0">
                                        <h3 className="text-2xl font-black tracking-tight leading-none mb-2 italic uppercase truncate">{lead.name}</h3>
                                        <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest truncate">{lead.email}</div>
                                     </div>
                                  </div>
                                  <div className="flex items-center gap-4 shrink-0">
                                     <span className={cn("text-[9px] font-black uppercase px-3 py-1.5 rounded-full tracking-widest border border-white/10", lead.status === 'new' ? "bg-blue-600 text-white border-transparent shadow-[0_0_15px_rgba(37,99,235,0.3)]" : "bg-white/5 text-white/40")}>{lead.status}</span>
                                     {activeTab === 'bin' ? (
                                        <button onClick={() => deleteRecord('leads', lead.id)} title="Delete Forever" className="p-3 bg-white/5 hover:bg-rose-500/20 rounded-xl text-white/20 hover:text-rose-500 transition-all opacity-100 lg:opacity-0 group-hover:opacity-100"><Trash2 size={16} /></button>
                                     ) : (
                                        <button onClick={() => updateStatus('leads', lead.id, 'bin')} title="Move to Bin" className="p-3 bg-white/5 hover:bg-rose-500/20 rounded-xl text-white/20 hover:text-rose-500 transition-all opacity-100 lg:opacity-0 group-hover:opacity-100"><Trash2 size={16} /></button>
                                     )}
                                  </div>
                               </div>
                               <div className="bg-white/5 p-6 rounded-2xl mb-8 relative">
                                  <div className="absolute top-4 left-4 text-blue-500/20 italic font-serif text-4xl">"</div>
                                  <p className="text-white/70 italic leading-relaxed text-lg px-6 font-medium">
                                    {lead.message}
                                  </p>
                               </div>
                               <div className="flex items-center gap-4 pt-2">
                                  {activeTab === 'bin' ? (
                                     <button onClick={() => updateStatus('leads', lead.id, 'new')} className="px-6 py-3 bg-white text-black hover:bg-emerald-500 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Restore</button>
                                  ) : (
                                     <>
                                        <button onClick={() => updateStatus('leads', lead.id, 'contacted')} className="px-6 py-3 bg-white text-black hover:bg-blue-500 hover:text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Mark as Contacted</button>
                                        <button onClick={() => updateStatus('leads', lead.id, 'closed')} className="px-6 py-3 bg-white/5 border border-white/10 hover:bg-emerald-500/20 hover:text-emerald-500 rounded-xl text-[10px] font-black uppercase tracking-widest text-white/40 transition-all">Close Lead</button>
                                     </>
                                  )}
                               </div>
                            </div>
                          ))}
                        </>
                      )}
                      
                      {activeTab === 'bin' && filteredPackages.length === 0 && filteredGeneral.length === 0 && (
                        <div className="p-32 text-center text-white/10 font-bold uppercase tracking-[0.3em] border border-dashed border-white/5 rounded-[40px]">Bin empty...</div>
                      )}
                   </motion.div>

                   {/* System Logs */}
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-24 pb-12">
                      <div>
                        <div className="flex items-center gap-4 mb-8">
                           <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/20">
                              <Clock size={18} />
                           </div>
                           <div>
                              <h2 className="text-xl font-black uppercase tracking-tighter italic">Strategy Guidelines</h2>
                              <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Global directives</p>
                           </div>
                        </div>
                        <div className="bg-white/5 border border-white/10 rounded-[32px] p-8 text-[11px] uppercase tracking-wider space-y-4">
                           <div className="flex gap-4 text-white/60"><span className="text-blue-500 font-black shrink-0">[01]</span> <span>Inbound checkout actions are registered instantly in SyncCore Firestore.</span></div>
                           <div className="flex gap-4 text-white/60"><span className="text-blue-500 font-black shrink-0">[02]</span> <span>Contact clients via email to collect final specifications & briefs.</span></div>
                           <div className="flex gap-4 text-white/60"><span className="text-blue-500 font-black shrink-0">[03]</span> <span>Invoicing handled strictly externally (Stripe/QuickBooks).</span></div>
                           <div className="flex gap-4 text-white/60"><span className="text-blue-500 font-black shrink-0">[04]</span> <span>Adhere to standard GDPR protocols for confidential PII.</span></div>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-4 mb-8">
                           <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
                              <CheckCircle2 size={18} />
                           </div>
                           <div>
                              <h2 className="text-xl font-black uppercase tracking-tighter italic">Operator Tasks</h2>
                              <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Jobs to do & Follow Ups</p>
                           </div>
                        </div>
                        <div className="bg-white/5 border border-blue-500/20 rounded-[32px] p-8 space-y-4 relative overflow-hidden backdrop-blur-sm">
                           <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl" />
                           
                           {todos.map(todo => (
                             <div key={todo.id} className="flex gap-4 text-white/80 items-center justify-between p-4 bg-white/5 rounded-2xl group cursor-pointer" onClick={() => {
                                 const updated = todos.map(t => t.id === todo.id ? { ...t, done: !t.done } : t);
                                 setTodos(updated);
                                 localStorage.setItem('admin_todos', JSON.stringify(updated));
                             }}>
                               <span className={cn("text-[11px] font-bold uppercase tracking-wider flex-1", todo.done && "line-through text-white/40")}>{todo.text}</span>
                               <button 
                                 onClick={(e) => {
                                   e.stopPropagation();
                                   const updated = todos.filter(t => t.id !== todo.id);
                                   setTodos(updated);
                                   localStorage.setItem('admin_todos', JSON.stringify(updated));
                                 }}
                                 className="opacity-0 group-hover:opacity-100 p-2 hover:bg-rose-500/20 text-rose-500 rounded-lg transition-all"
                               >
                                 <Trash2 size={12} />
                               </button>
                             </div>
                           ))}

                           {todos.length === 0 && (
                             <div className="text-center py-4 text-white/20 text-[10px] font-bold uppercase tracking-widest">No tasks pending</div>
                           )}

                           <div className="flex gap-2 mt-4 relative z-10">
                              <input 
                                value={newTodo}
                                onChange={(e) => setNewTodo(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' && newTodo.trim()) {
                                     const updated = [...todos, { id: Math.random().toString(), text: newTodo.trim(), done: false }];
                                     setTodos(updated);
                                     localStorage.setItem('admin_todos', JSON.stringify(updated));
                                     setNewTodo('');
                                  }
                                }}
                                placeholder="Add new task and press Enter..." 
                                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-[10px] font-bold uppercase tracking-widest placeholder:text-white/20 focus:outline-none focus:border-blue-500/50"
                              />
                           </div>
                        </div>
                      </div>
                   </div>
                </div>

                {/* Right Rail: Activity Summary */}
                <div className="space-y-8">
                   <div className="p-8 rounded-[40px] bg-white text-black h-fit shadow-2xl">
                      <div className="text-[10px] font-black uppercase tracking-[0.2em] mb-8 flex items-center justify-between">
                         Recent Activity
                         <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                      </div>
                      <div className="space-y-8">
                         {[...packageEnquiries, ...generalEnquiries]
                           .sort((a, b) => getTimestampMs(b) - getTimestampMs(a))
                           .slice(0, 5)
                           .map((item, i) => {
                              const isOrder = !item.name;
                              const timestamp = getTimestampMs(item);
                              const timeLabel = timestamp ? formatTime(item) : 'RECENT';
                              const dateLabel = timestamp ? formatDateLabel(item) : '';
                              return (
                                <div key={i} className="flex gap-4">
                                   <div className={cn("w-1 h-12 rounded-full mt-1 shrink-0", isOrder ? "bg-blue-600" : "bg-emerald-500")} />
                                   <div className="min-w-0">
                                      <div className="text-[9px] font-black uppercase tracking-wider mb-1 flex flex-wrap items-center gap-1">
                                         <span className={isOrder ? "text-blue-600" : "text-emerald-500"}>
                                           {isOrder ? 'PROJECT ENQUIRY' : 'GENERAL MSG'}
                                         </span>
                                         {dateLabel && <span className="text-black/30 font-bold">· {dateLabel}</span>}
                                      </div>
                                      <p className="text-xs text-black/80 font-bold leading-tight mb-1 truncate">
                                         {item.customerName || item.name}
                                      </p>
                                      <div className="text-[9px] font-bold text-black/30 uppercase tracking-widest">
                                         {timeLabel}
                                       </div>
                                   </div>
                                </div>
                              );
                           })
                         }
                         {[...packageEnquiries, ...generalEnquiries].length === 0 && (
                           <div className="text-center py-6 text-black/30 text-[10px] font-black uppercase tracking-widest">
                             No records synced yet
                           </div>
                         )}
                      </div>
                   </div>

                   <div className="p-10 rounded-[40px] bg-blue-600 text-white relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -translate-y-12 translate-x-12" />
                      <div className="text-[10px] font-black uppercase tracking-[0.2em] mb-6 opacity-60">System Health</div>
                      <div className="text-4xl font-black italic tracking-tighter mb-2 leading-none uppercase">98.4%</div>
                      <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-8">Performance Index</p>
                      <div className="space-y-4">
                         <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                           <div className="h-full w-[94%] bg-white group-hover:w-[98%] transition-all duration-1000" />
                         </div>
                         <div className="flex justify-between text-[8px] font-black uppercase tracking-widest">
                            <span>Efficiency</span>
                            <span>98%</span>
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
      </main>
    </div>
  );
}

