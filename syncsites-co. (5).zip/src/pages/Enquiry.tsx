import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import { usePackage } from '../context/PackageContext';
import { ArrowLeft, ClipboardList, CheckCircle2, ChevronRight, ShieldCheck, Loader2 } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { cn } from '../lib/utils';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default function Enquiry() {
  const { selectedPackage, clearPackage } = usePackage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    phone: '',
    businessName: '',
    notes: '',
  });

  useEffect(() => {
    const success = searchParams.get('success');
    if (success) {
      setIsSuccess(true);
      setStep(3);
    }
  }, [searchParams]);

  if (!selectedPackage && !isSuccess) {
    return (
      <div className="pt-40 pb-24 min-h-screen flex flex-col items-center justify-center px-6">
        <Meta title="Start Enquiry | SyncSites Co." />
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="text-center"
        >
          <div className="w-20 h-20 bg-white/5 border border-white/10 rounded-full flex items-center justify-center mx-auto mb-8 text-blue-500 bg-blue-500/5">
             <ClipboardList size={32} />
          </div>
          <h1 className="text-3xl font-bold mb-4 uppercase tracking-tighter italic">Start Your Project</h1>
          <p className="text-white/40 mb-10 max-w-sm mx-auto">Select a website package to submit an enquiry and schedule a consultation with our team.</p>
          <Link
            to="/packages"
            className="px-8 py-4 bg-white text-black rounded-xl font-bold hover:bg-blue-50 transition-all shadow-xl uppercase tracking-wider text-xs"
          >
            Review Packages
          </Link>
        </motion.div>
      </div>
    );
  }

  const [managementTier, setManagementTier] = useState<number>(selectedPackage?.monthlyFee || 20);

  const handleEnquirySubmit = async () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.businessName) {
      alert("Please complete all required fields (Name, Email, Phone Number, and Business Name) first.");
      setStep(1);
      return;
    }

    setLoading(true);
    try {
      // 1. Record lead/enquiry attempt in Firestore
      const orderRef = collection(db, 'orders');
      await addDoc(orderRef, {
        ...formData,
        customerName: formData.name, 
        packageId: selectedPackage?.id,
        packageName: selectedPackage?.name,
        price: selectedPackage?.price,
        monthlyFee: managementTier,
        status: 'pending',
        createdAt: serverTimestamp(),
      });

      // 2. Dispatch automated CRM confirmation follow-up email
      try {
        await fetch('/api/enquiry', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            businessName: formData.businessName,
            packageName: selectedPackage?.name,
            price: selectedPackage?.price,
            monthlyFee: managementTier,
            notes: formData.notes,
          }),
        });
      } catch (err) {
        console.warn("CRM email triggers offline/delayed:", err);
      }

      // Advance directly to success step
      setIsSuccess(true);
      setStep(3);
    } catch (error: any) {
      console.error('Submission failed:', error);
      alert(error.message || "Something went wrong. Please check your details and try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleNext = () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.businessName) {
      alert("Please fill in all required fields (Name, Email, Phone, and Business Name) before proceeding.");
      return;
    }
    setStep(prev => prev + 1);
  };

  return (
    <div className="pt-40 pb-24 px-6 min-h-screen relative overflow-hidden">
      <Meta title={isSuccess ? "Enquiry Received | SyncSites Co." : `Enquiry: ${selectedPackage?.name} | SyncSites Co.`} />
      
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Left Col: Flow */}
        <div className="lg:col-span-7">
          {!isSuccess && (
            <>
              <button
                onClick={() => navigate(-1)}
                aria-label="Go back"
                className="flex items-center gap-2 text-white/40 hover:text-white transition-colors mb-12 uppercase text-[10px] font-bold tracking-widest"
              >
                <ArrowLeft size={16} />
                Back to plans
              </button>

              <div className="flex items-center gap-4 mb-16">
                 <div className="flex items-center gap-2">
                    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors", step >= 1 ? "bg-blue-600 text-white" : "bg-white/5 border border-white/10 text-white/20")}>1</div>
                    <span className={cn("text-sm font-bold uppercase tracking-widest", step >= 1 ? "text-white" : "text-white/20")}>Details</span>
                 </div>
                 <div className="w-12 h-[1px] bg-white/10" />
                 <div className="flex items-center gap-2">
                    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors", step >= 2 ? "bg-blue-600 text-white" : "bg-white/5 border border-white/10 text-white/20")}>2</div>
                    <span className={cn("text-sm font-bold uppercase tracking-widest", step >= 2 ? "text-white" : "text-white/20")}>Review</span>
                 </div>
                 <div className="w-12 h-[1px] bg-white/10" />
                 <div className="flex items-center gap-2">
                    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors", step >= 3 ? "bg-blue-600 text-white" : "bg-white/5 border border-white/10 text-white/20")}>3</div>
                    <span className={cn("text-sm font-bold uppercase tracking-widest", step >= 3 ? "text-white" : "text-white/20")}>Complete</span>
                 </div>
              </div>
            </>
          )}

          {step === 1 && (
            <motion.div
               initial={{ opacity: 0, x: -20 }}
               animate={{ opacity: 1, x: 0 }}
               className="space-y-8"
            >
               <div>
                  <h2 className="text-3xl font-bold mb-2 tracking-tight uppercase">Business Information</h2>
                  <p className="text-white/40">Provide your contact details so we can review your requirements and get in touch.</p>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Full Name *</label>
                     <input
                        type="text"
                        placeholder="John Doe"
                        aria-label="Full Name"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-white/10"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                     />
                  </div>
                   <div className="space-y-2">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Email Address *</label>
                     <input
                        type="email"
                        placeholder="john@example.com"
                        aria-label="Email Address"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-white/10"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                     />
                  </div>
                  <div className="space-y-2">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Phone Number *</label>
                     <input
                        type="tel"
                        placeholder="+44 7700 900077"
                        aria-label="Phone Number"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-white/10"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                     />
                  </div>
                  <div className="space-y-2">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Business Name *</label>
                     <input
                        type="text"
                        placeholder="Your Company Co."
                        aria-label="Business Name"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-white/10"
                        value={formData.businessName}
                        onChange={(e) => setFormData({...formData, businessName: e.target.value})}
                     />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                     <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Project & Business Requirements (Optional)</label>
                     <textarea
                        rows={4}
                        placeholder="Tell us a bit about your company, target audience, and style choices..."
                        aria-label="Project Requirements"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-white/10 resize-none"
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                     />
                  </div>
               </div>
               <button
                  onClick={handleNext}
                  className="w-full md:w-auto px-10 py-4 bg-white text-black rounded-xl font-bold hover:bg-blue-50 transition-all flex items-center justify-center gap-2 group uppercase tracking-tight"
               >
                  Review Enquiry
                  <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
               </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
               initial={{ opacity: 0, x: -20 }}
               animate={{ opacity: 1, x: 0 }}
               className="space-y-8"
            >
               <div>
                  <h2 className="text-3xl font-bold mb-2 tracking-tight uppercase">Confirm Enquiry Details</h2>
                  <p className="text-white/40">Please review your information below before submitting. No payment is required to submit an enquiry.</p>
               </div>

               <div className="p-6 bg-white/5 border border-white/10 rounded-2xl space-y-3.5 text-xs leading-relaxed uppercase tracking-widest font-bold">
                  <div className="text-[10px] text-white/40 mb-1">Registered Contact Details:</div>
                  <div className="flex justify-between">
                     <span className="text-white/40">Full Name</span>
                     <span className="text-white">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                     <span className="text-white/40">Email Address</span>
                     <span className="text-white lowercase font-medium">{formData.email}</span>
                  </div>
                  <div className="flex justify-between">
                     <span className="text-white/40">Phone Number</span>
                     <span className="text-white">{formData.phone}</span>
                  </div>
                  <div className="flex justify-between">
                     <span className="text-white/40">Business Name</span>
                     <span className="text-white font-black">{formData.businessName}</span>
                  </div>
               </div>

               <div className="space-y-4">
                  <div className="p-6 bg-white/5 border border-blue-600 rounded-2xl flex items-center justify-between backdrop-blur-sm">
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-600/10 rounded-lg flex items-center justify-center text-blue-500">
                           <ShieldCheck size={20} />
                        </div>
                        <div>
                           <div className="font-bold text-white uppercase tracking-tight text-sm">Submit Project Enquiry</div>
                           <div className="text-[10px] text-white/40 uppercase font-bold tracking-widest">No upfront cards required · 100% Secure</div>
                        </div>
                     </div>
                     <div className="w-6 h-6 rounded-full border-2 border-blue-600 flex items-center justify-center">
                        <div className="w-3 h-3 rounded-full bg-blue-600" />
                     </div>
                  </div>

                  <div className="p-5 bg-blue-600/10 border border-blue-500/20 rounded-2xl text-[11px] leading-relaxed text-blue-300 space-y-2 font-medium">
                     <p className="font-black uppercase tracking-wider text-white">Next Steps:</p>
                     <ul className="list-disc pl-4 space-y-1.5 uppercase tracking-widest text-[9px]">
                        <li>Submitting this form places a priority enquiry in our pipeline limit.</li>
                        <li>We'll review your requirements and package selection.</li>
                        <li>Our team will contact you to arrange a strategy call and finalise pricing.</li>
                     </ul>
                  </div>
               </div>

               <div className="space-y-4">
                  <button
                    onClick={handleEnquirySubmit}
                    disabled={loading}
                    className="w-full py-5 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-500 transition-all flex items-center justify-center gap-3 shadow-[0_0_50px_rgba(37,99,235,0.3)] uppercase tracking-tight disabled:opacity-50"
                  >
                     {loading ? <Loader2 className="animate-spin" size={24} /> : <><CheckCircle2 size={20} /> Submit Enquiry</>}
                  </button>
                  <p className="text-white/20 text-[10px] text-center uppercase font-bold tracking-widest pt-4">
                     By confirming your details, you agree to our <Link to="/terms" className="underline hover:text-white">Terms of Service</Link>.
                  </p>
               </div>
            </motion.div>
          )}

           {step === 3 && (
            <motion.div
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               className="text-center py-10"
            >
               <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-10 shadow-[0_0_50px_rgba(37,99,235,0.5)] border border-white/20">
                   <CheckCircle2 size={48} className="text-white" />
               </div>
               <h2 className="text-4xl font-bold mb-4 italic uppercase tracking-tighter leading-none">Enquiry Received successfully</h2>
               <p className="text-white/40 mb-10 max-w-sm mx-auto">Thank you for your interest in SyncSites Co. A developer from our team will review your request and contact you shortly.</p>
               <div className="space-y-4">
               <button
                  onClick={() => {
                        clearPackage();
                        navigate('/');
                  }}
                  className="px-12 py-5 bg-white text-black rounded-xl font-bold hover:bg-blue-50 transition-all shadow-xl uppercase tracking-tight"
               >
                  Back to Homepage
               </button>
               </div>
            </motion.div>
          )}
        </div>

        {/* Right Col: Summary */}
        <div className="lg:col-span-5">
           {selectedPackage && !isSuccess && (
             <div className="sticky top-40 bg-white/5 border border-white/10 rounded-3xl p-8 shadow-2xl overflow-hidden backdrop-blur-sm">
                 {/* Accent line */}
                 <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-blue-600 to-indigo-500" />

                 <h3 className="text-[10px] font-bold mb-8 uppercase tracking-[0.2em] text-white/30">Package Interest</h3>

                 <div className="space-y-6 mb-8 pb-8 border-b border-white/10">
                    <div className="flex justify-between items-start">
                       <div>
                          <div className="font-bold text-white text-lg tracking-tight uppercase">{selectedPackage.name}</div>
                          <div className="text-xs text-white/40 uppercase tracking-widest font-bold">Custom Website Build</div>
                       </div>
                       <div className="font-bold text-white text-lg tracking-tighter">£{selectedPackage.price}</div>
                    </div>

                    <div className="space-y-4">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Select Required Management Plan</label>
                        <div className="grid grid-cols-1 gap-3">
                           <button 
                             onClick={() => setManagementTier(20)}
                             className={cn("p-4 rounded-xl border flex flex-col text-left transition-all", managementTier === 20 ? "bg-white/10 border-blue-500" : "bg-white/5 border-white/10 hover:bg-white/[0.08]")}
                           >
                              <div className="flex justify-between items-center w-full mb-1">
                                 <span className="font-bold uppercase tracking-tight text-sm text-white">Essential Care</span>
                                 <span className="font-bold text-white tracking-tighter">£20/mo</span>
                              </div>
                              <span className="text-[10px] text-white/40 uppercase tracking-widest font-bold">Hosting, SSL & Core Updates</span>
                           </button>

                           <button 
                             onClick={() => setManagementTier(49.99)}
                             className={cn("p-4 rounded-xl border flex flex-col text-left transition-all relative overflow-hidden", managementTier === 49.99 ? "bg-blue-600/10 border-blue-500" : "bg-white/5 border-white/10 hover:bg-white/[0.08]")}
                           >
                              {managementTier === 49.99 && <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/20 rounded-full blur-xl" />}
                              <div className="flex justify-between items-center w-full mb-1 relative z-10">
                                 <span className="font-bold uppercase tracking-tight text-sm text-blue-400">Premium Care</span>
                                 <span className="font-bold text-white tracking-tighter">£49.99/mo</span>
                              </div>
                              <span className="text-[10px] text-white/60 uppercase tracking-widest font-bold relative z-10">Priority Support + Content Updates</span>
                           </button>
                        </div>
                    </div>
                 </div>

                 <div className="space-y-4 mb-10">
                    <div className="flex justify-between text-white/40 font-bold uppercase text-[10px] tracking-widest">
                       <span>Build Estimate</span>
                       <span className="text-white tracking-tighter">£{selectedPackage.price}</span>
                    </div>
                    <div className="flex justify-between text-white/40 font-bold uppercase text-[10px] tracking-widest">
                       <span>Selected Monthly Support</span>
                       <span className="text-white tracking-tighter">£{managementTier}/mo</span>
                    </div>
                    <div className="pt-6 border-t border-white/10 flex justify-between items-end">
                       <span className="text-white font-bold text-sm uppercase tracking-widest">Due Today</span>
                       <span className="text-blue-500 font-black text-4xl tracking-tighter leading-none">£0.00</span>
                    </div>
                 </div>

                 <div className="bg-white/5 p-6 rounded-2xl space-y-4 border border-white/5">
                    <div className="flex items-center gap-3 text-[10px] font-bold text-white/60 uppercase tracking-widest">
                       <CheckCircle2 size={16} className="text-blue-500" />
                       Fast technical delivery
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-white/60 uppercase tracking-widest">
                       <CheckCircle2 size={16} className="text-blue-500" />
                       SEO-ready hand-written code
                    </div>
                     <div className="flex items-center gap-3 text-[10px] font-bold text-white/60 uppercase tracking-widest">
                       <CheckCircle2 size={16} className="text-blue-500" />
                       Clear, realistic timelines
                    </div>
                 </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
}

