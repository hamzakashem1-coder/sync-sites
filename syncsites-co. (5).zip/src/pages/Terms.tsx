import { motion } from 'motion/react';
import Meta from '../components/common/Meta';

export default function Terms() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen"
    >
        <Meta title="Terms of Service | SyncSites Co." description="Detailed terms of service for partnering with SyncSites Co. for web design and management." />
        
        <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-12 tracking-tighter uppercase whitespace-nowrap">
              Terms of <span className="text-white/40 italic">Service</span>
            </h1>

            <div className="space-y-12 text-white/60 leading-relaxed text-lg">
                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">1. Acceptance of Terms</h2>
                    <p>By engaging SyncSites Co. for services or accessing this website, you agree to be bound by these Terms of Service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">2. Service Provision</h2>
                    <p>SyncSites Co. provides professional web design, development, SEO, and ongoing maintenance services. The specific deliverables, timelines, and costs for each project are outlined in the selected Service Package or Custom Proposal.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">3. Client Responsibilities</h2>
                    <p>Clients are responsible for providing necessary brand assets, content, and feedback in a timely manner. Delays in providing required information may result in adjustments to delivery timelines.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">4. Payments & Subscriptions</h2>
                    <p>One-time project fees must be paid according to the agreed schedule. Monthly managed packages are billed recurringly until cancelled. SyncSites Co. reserves the right to suspend services (including hosting) for accounts with overdue balances.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">5. Intellectual Property</h2>
                    <p>Full ownership of the custom design and code is transferred to the client upon full payment of the project fee. SyncSites Co. retains a non-exclusive right to display the work in our portfolio and marketing materials.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">6. Limitation of Liability</h2>
                    <p>To the maximum extent permitted by law, SyncSites Co. shall not be liable for any indirect, incidental, special, or consequential damages resulting from the use or inability to use our services.</p>
                </section>

                 <p className="text-sm text-white/20 italic pt-12 border-t border-white/5 font-mono">
                    Last updated: May 16, 2026. SyncSites Co. / Operations Dept.
                 </p>
            </div>
        </div>
    </motion.div>
  );
}
