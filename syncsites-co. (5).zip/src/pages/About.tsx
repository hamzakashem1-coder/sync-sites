import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import { Target, Users, Zap, ShieldCheck, Heart } from 'lucide-react';
import FinalCTA from '../components/Home/FinalCTA';

export default function About() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-20"
    >
        <Meta 
            title="Our DNA | SyncSites Co." 
            description="Learn about our mission to become the global standard for high-performance business web presence and our relentless obsession with client growth."
        />
        <section className="py-24 px-6 relative overflow-hidden">
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <motion.div
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                >
                    <div className="text-blue-500 font-bold uppercase tracking-widest text-[10px] mb-6">Our DNA</div>
                    <h1 className="text-5xl md:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
                       More Than An Agency. <br />
                       <span className="text-white/40 italic">A Growth Partner.</span>
                    </h1>
                    <p className="text-white/40 text-xl mb-10 leading-relaxed">
                       SyncSites Co. was founded on a simple belief: businesses deserve better than average websites. In a world where your digital presence is your most valuable asset, we refuse to settle for templates and fluff.
                    </p>
                    <div className="space-y-6">
                        <div className="flex gap-4">
                            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-500 shrink-0">
                                <Target size={24} />
                            </div>
                            <div>
                                <h3 className="font-bold text-lg mb-1 tracking-tight uppercase">Our Mission</h3>
                                <p className="text-white/40 text-sm">To transform how businesses scale online by combining elite design with conversion psychology.</p>
                            </div>
                        </div>
                         <div className="flex gap-4">
                            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-blue-500 shrink-0">
                                <Users size={24} />
                            </div>
                            <div>
                                <h3 className="font-bold text-lg mb-1 tracking-tight uppercase">Our Vision</h3>
                                <p className="text-white/40 text-sm">To become the global standard for high-performance business web presence.</p>
                            </div>
                        </div>
                    </div>
                </motion.div>

                <div className="relative">
                    <div className="aspect-[4/5] rounded-3xl bg-white/5 border border-white/10 overflow-hidden shadow-2xl backdrop-blur-sm">
                         <img
                            src="https://images.unsplash.com/photo-1522071823991-b9671f9d7f1f?auto=format&fit=crop&q=80&w=2400"
                            alt="Agency Team"
                            className="w-full h-full object-cover grayscale opacity-50 transition-all hover:grayscale-0 hover:opacity-100 duration-700"
                            referrerPolicy="no-referrer"
                         />
                    </div>
                    {/* Floating badge */}
                    <div className="absolute -bottom-10 -left-10 p-10 bg-blue-600 rounded-3xl text-white shadow-[0_0_50px_rgba(37,99,235,0.4)] border border-white/20">
                        <div className="text-5xl font-black mb-1 italic">50+</div>
                        <div className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">Brands Grown</div>
                    </div>
                </div>
            </div>
        </section>

        {/* Values Section */}
        <section className="py-24 px-6 relative">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-20">
                    <h2 className="text-4xl md:text-6xl font-bold tracking-tight">Our Core <span className="text-white/40 italic">Values</span></h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { title: 'Radical Integrity', icon: ShieldCheck, desc: 'We say what we do and we do what we say. No hidden fees, no fluff.' },
                        { title: 'Relentless Innovation', icon: Zap, desc: 'The web moves fast. We stay ahead of the curve so you don’t have to.' },
                        { title: 'Client Obsession', icon: Heart, desc: 'Your growth is our only metric of success. We are part of your team.' },
                    ].map((value, i) => (
                        <div key={i} className="p-10 rounded-3xl bg-white/5 border border-white/10 hover:border-blue-500/50 group transition-all backdrop-blur-sm">
                             <div className="w-14 h-14 bg-white/5 rounded-xl flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all text-blue-500 border border-white/10 group-hover:border-blue-600">
                                <value.icon size={28} />
                             </div>
                             <h3 className="text-2xl font-bold mb-4 tracking-tight uppercase">{value.title}</h3>
                             <p className="text-white/40 leading-relaxed text-sm">{value.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        <FinalCTA />
    </motion.div>
  );
}
