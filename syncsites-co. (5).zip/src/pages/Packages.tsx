import { motion } from 'motion/react';
import Meta from '../components/common/Meta';
import PackagesSection from '../components/Home/PackagesSection';
import WhyChooseSection from '../components/Home/WhyChooseSection';
import FAQSection from '../components/Home/FAQSection';

export default function Packages() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-20"
    >
        <Meta 
            title="Pricing & Packages | Invest in Your Growth" 
            description="Transparent pricing for premium digital growth. Choose between one-time builds and fully managed high-stakes business packages."
        />
        <div className="py-24 px-6 text-center overflow-hidden relative">
             <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-4xl mx-auto"
             >
                <div className="text-blue-500 font-bold uppercase tracking-widest text-[10px] mb-6">Investment & Partnerships</div>
                <h1 className="text-5xl md:text-8xl font-bold mb-8 leading-[0.9] tracking-tighter">
                    Growth Plans Built for <br />
                    <span className="text-white/40 italic">High-Stakes Businesses</span>
                </h1>
                <p className="text-white/40 text-xl max-w-2xl mx-auto leading-relaxed">
                    Transparent pricing. Premium results. No surprises. Choose the plan that fits your current stage of growth.
                </p>
             </motion.div>
        </div>

        <PackagesSection />
        <WhyChooseSection />
        <FAQSection />

        <div className="py-24 px-6">
            <div className="max-w-4xl mx-auto p-12 rounded-3xl bg-white/5 border border-white/10 text-center relative overflow-hidden backdrop-blur-sm">
                 <div className="absolute top-0 right-0 p-8 text-blue-500 opacity-10">
                    <svg width="200" height="200" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="100" cy="100" r="100" fill="currentColor" />
                    </svg>
                 </div>

                 <h3 className="text-3xl font-bold mb-6 relative z-10 tracking-tight">Need something even bigger?</h3>
                 <p className="text-white/40 text-lg mb-10 max-w-xl mx-auto relative z-10">
                    If your business requires a custom enterprise solution, deep integrations, or advanced customer portals, let’s have a strategy call.
                 </p>
                 <button className="px-10 py-4 bg-white text-black rounded-xl font-bold hover:bg-blue-50 transition-all relative z-10">
                    Request Custom Quote
                 </button>
            </div>
        </div>
    </motion.div>
  );
}
