import { motion } from 'motion/react';
import Meta from '../components/common/Meta';

export default function Disclaimer() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen"
    >
        <Meta title="Legal Disclaimer | SyncSites Co." description="Legal transparency and disclaimer for SyncSites Co. services and content." />
        
        <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-12 tracking-tighter uppercase">
              Legal <span className="text-white/40 italic">Disclaimer</span>
            </h1>

            <div className="space-y-12 text-white/60 leading-relaxed text-lg">
                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">1. General Information</h2>
                    <p>The information provided by SyncSites Co. on our website and through our services is for general informational purposes only. All information is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability or completeness of any information.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">2. Business Results</h2>
                    <p>While we specialize in conversion optimization and high-performance web design, we cannot guarantee specific revenue increases or business outcomes. Market conditions, product quality, and external factors beyond our control significantly influence business success.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">3. Technical Limitations</h2>
                    <p>We strive for 99.9% uptime and peak performance for all projects we manage. However, we are not responsible for downtime caused by third-party hosting failures, DNS issues, or global internet structural problems.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">4. External Links</h2>
                    <p>Our website may contain links to external websites that are not provided or maintained by or in any way affiliated with SyncSites Co. Please note that we do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.</p>
                </section>

                 <p className="text-sm text-white/20 italic pt-12 border-t border-white/5 font-mono">
                    Last updated: May 16, 2026. SyncSites Co. / Legal Compliance
                 </p>
            </div>
        </div>
    </motion.div>
  );
}
