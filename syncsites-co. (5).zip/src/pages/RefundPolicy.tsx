import { motion } from 'motion/react';
import Meta from '../components/common/Meta';

export default function RefundPolicy() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen"
    >
        <Meta title="Refund Policy | SyncSites Co." description="SyncSites Co. refund and cancellation policy for digital services and subscriptions." />
        
        <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-12 tracking-tighter uppercase">
              Refund <span className="text-white/40 italic">Policy</span>
            </h1>

            <div className="space-y-12 text-white/60 leading-relaxed text-lg">
                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">1. Digital Services</h2>
                    <p>Due to the nature of digital design and development services, work completed and delivered is generally non-refundable. We put high effort into ensuring every pixel meets your standards before delivery.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">2. Subscription Cancellations</h2>
                    <p>For monthly managed packages (Growth and Commerce), you may cancel at any time. Cancellation will take effect at the end of the current billing cycle. No partial refunds are provided for unused days in a billing period.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">3. Satisfaction Guarantee</h2>
                    <p>If you are unsatisfied with the initial design phase, we offer a "pre-development" refund option. Once development has commenced on the actual code and infrastructure, costs incurred become non-refundable.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">4. Disputes</h2>
                    <p>We encourage clients to reach out to our support team directly to resolve any issues. We pride ourselves on our 99% client satisfaction rate and will work tirelessly to ensure you are happy with the end product.</p>
                </section>

                 <p className="text-sm text-white/20 italic pt-12 border-t border-white/5 font-mono">
                    Last updated: May 16, 2026. SyncSites Co. / Billing Department
                 </p>
            </div>
        </div>
    </motion.div>
  );
}
