import { motion } from 'motion/react';
import Meta from '../components/common/Meta';

export default function Cookies() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen"
    >
        <Meta title="Cookie Policy | SyncSites Co." description="Read about how SyncSites Co. uses cookies to improve your user experience." />
        
        <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-12 tracking-tighter uppercase whitespace-nowrap">
              Cookie <span className="text-white/40 italic">Policy</span>
            </h1>

            <div className="space-y-12 text-white/60 leading-relaxed text-lg">
                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">1. What Are Cookies</h2>
                    <p>Cookies are small text files that are stored on your device when you visit our website. They help us make the site work better for you, understand how you use it, and personalize your experience.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">2. Types of Cookies We Use</h2>
                    <div className="space-y-4">
                        <div>
                            <h3 className="text-white font-bold mb-1">Essential Cookies</h3>
                            <p className="text-sm">Necessary for the website to function correctly. These cannot be disabled in our systems.</p>
                        </div>
                        <div>
                            <h3 className="text-white font-bold mb-1">Analytics Cookies</h3>
                            <p className="text-sm">Help us measure performance and see which pages are most popular. All information collected is aggregated and anonymous.</p>
                        </div>
                        <div>
                            <h3 className="text-white font-bold mb-1">Functional Cookies</h3>
                            <p className="text-sm">Allow the website to provide enhanced functionality and personalization based on your interactions.</p>
                        </div>
                    </div>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">3. Managing Your Preferences</h2>
                    <p>You can manage your cookie preferences at any time through our cookie consent banner or by adjusting your browser settings. Please note that disabling certain cookies may affect the functionality of our website.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">4. Third-Party Cookies</h2>
                    <p>Some cookies are placed by third-party services that appear on our pages. We do not control these cookies; please refer to the respective third-party privacy policies for more information (e.g., Stripe, Google Analytics).</p>
                </section>

                 <p className="text-sm text-white/20 italic pt-12 border-t border-white/5 font-mono">
                    Last updated: May 16, 2026. SyncSites Co. / Digital Operations
                 </p>
            </div>
        </div>
    </motion.div>
  );
}
