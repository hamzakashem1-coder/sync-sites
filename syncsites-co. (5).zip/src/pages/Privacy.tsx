import { motion } from 'motion/react';
import Meta from '../components/common/Meta';

export default function Privacy() {
  return (
    <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="pt-40 pb-24 px-6 min-h-screen"
    >
        <Meta title="Privacy Policy | SyncSites Co." description="Your privacy is paramount. Read more about how SyncSites Co. handles your data and security." />
        
        <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-12 tracking-tighter uppercase whitespace-nowrap">
              Privacy <span className="text-white/40 italic">Policy</span>
            </h1>

            <div className="space-y-12 text-white/60 leading-relaxed text-lg">
                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">1. Information We Collect</h2>
                    <p>We collect information you provide directly to us (name, email, business details) and automated usage data via cookies to improve site performance and your user experience.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">2. Use of Data</h2>
                    <p>Your data is used strictly for service delivery, communication, and processing of payments via secure providers. We do not sell or trade your personal information with third parties for marketing purposes.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">3. Security Standards</h2>
                    <p>We implement enterprise-grade security protocols to protect your data. All sensitive communications and payment transactions are encrypted and handled through secure industry-standard gateways.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">4. Data Retention</h2>
                    <p>We retain your personal information only for as long as necessary to provide you with our services and as required for legal compliance and bookkeeping purposes.</p>
                </section>

                <section>
                    <h2 className="text-2xl font-bold text-white mb-6 tracking-tight uppercase">5. Your Digital Rights</h2>
                    <p>Under GDPR and other privacy frameworks, you have the right to access, correct, or delete your personal data. You can exercise these rights by contacting our security team at hello@syncsites.co.</p>
                </section>

                 <p className="text-sm text-white/20 italic pt-12 border-t border-white/5 font-mono">
                    Last updated: May 16, 2026. SyncSites Co. / Security Compliance
                 </p>
            </div>
        </div>
    </motion.div>
  );
}
