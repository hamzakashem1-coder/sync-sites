/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'motion/react';
import { PackageProvider } from './context/PackageContext';
import Home from './pages/Home';
import Packages from './pages/Packages';
import Portfolio from './pages/Portfolio';
import About from './pages/About';
import Contact from './pages/Contact';
import Enquiry from './pages/Enquiry';
import Admin from './pages/Admin';
import FAQ from './pages/FAQ';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Cookies from './pages/Cookies';
import RefundPolicy from './pages/RefundPolicy';
import Disclaimer from './pages/Disclaimer';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import CookieConsent from './components/layout/CookieConsent';
import Chatbot from './components/common/Chatbot';
import { useEffect } from 'react';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location}>
        <Route path="/" element={<Home />} />
        <Route path="/packages" element={<Packages />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/enquiry" element={<Enquiry />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/cookies" element={<Cookies />} />
        <Route path="/refund-policy" element={<RefundPolicy />} />
        <Route path="/disclaimer" element={<Disclaimer />} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <PackageProvider>
      <Router>
        <ScrollToTop />
        <AppLayout />
      </Router>
    </PackageProvider>
  );
}

function AppLayout() {
  const location = useLocation();
  const isAdminPage = location.pathname === '/admin';

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-blue-500/30 selection:text-blue-200 relative overflow-hidden">
      {/* Global Ambient Glows */}
      {!isAdminPage && (
        <>
          <div className="absolute top-[-200px] right-[-200px] w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"></div>
          <div className="absolute bottom-[-100px] left-[-100px] w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[100px] pointer-events-none"></div>
        </>
      )}
      
      {/* Grid Overlay */}
      <div className="absolute inset-0 bg-grid opacity-50 pointer-events-none"></div>

      <div className="relative z-10">
        {!isAdminPage && <Navbar />}
        <AnimatedRoutes />
        {!isAdminPage && <Footer />}
        {!isAdminPage && <CookieConsent />}
        {!isAdminPage && <Chatbot />}
      </div>
    </div>
  );
}

