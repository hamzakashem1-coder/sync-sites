import { createContext, useContext, useState, ReactNode } from 'react';

export interface PackageItem {
  id: string;
  name: string;
  price: number;
  setupFee?: number;
  monthlyFee?: number;
}

interface PackageContextType {
  selectedPackage: PackageItem | null;
  selectPackage: (item: PackageItem) => void;
  clearPackage: () => void;
}

const PackageContext = createContext<PackageContextType | undefined>(undefined);

export function PackageProvider({ children }: { children: ReactNode }) {
  const [selectedPackage, setSelectedPackage] = useState<PackageItem | null>(null);

  const selectPackage = (item: PackageItem) => {
    setSelectedPackage(item);
  };

  const clearPackage = () => {
    setSelectedPackage(null);
  };

  return (
    <PackageContext.Provider value={{ selectedPackage, selectPackage, clearPackage }}>
      {children}
    </PackageContext.Provider>
  );
}

export function usePackage() {
  const context = useContext(PackageContext);
  if (context === undefined) {
    throw new Error('usePackage must be used within a PackageProvider');
  }
  return context;
}
