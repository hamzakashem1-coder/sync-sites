# Security Specification: SyncSites Co.

### Data Invariants
1. A **Lead** must have a valid name, email, and message. Once created, it cannot be edited by the client (system only).
2. An **Order** must reference a valid package. Its status can only be updated by an Admin.
3. **PII Isolation**: Leads and Orders containing customer emails and names must only be readable by Admins.

### The Dirty Dozen Payloads (Targeting Rejection)
1. Creating a lead with an ID longer than 128 chars.
2. Updating a lead's status from a client.
3. Reading all leads without being an admin.
4. Creating an order with a price of £0 via manual payload injection.
5. Deleting an existing order from the client.
6. Spoofing `createdAt` with a past timestamp.
7. Injecting a 1MB string into the business name.
8. Listing orders while not authenticated as an Admin.
9. Updating an order's `customerEmail` after creation.
10. Creating a lead without a message field.
11. Reading specific order details via direct ID guessing without admin rights.
12. Creating a lead with a spoofed status of 'contacted'.

### Verification Plan
- `firestore.rules` will enforce strict schema checks and use the "Admin" collection as the source of truth for elevated privileges.
