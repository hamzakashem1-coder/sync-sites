import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import Stripe from "stripe";
import { Resend } from "resend";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = reportExpressErrors() || express();
const PORT = 3000;

// Simple helper to avoid Express crashes if app is misconfigured (fallback)
function reportExpressErrors() {
  return null;
}

// Lazy initialize Gemini
let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

// Lazy initialize Stripe
let stripeClient: Stripe | null = null;
function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  
  if (!stripeClient) {
    // Basic validation to catch clearly wrong keys early
    if (!key.startsWith('sk_')) {
      console.error("CRITICAL: STRIPE_SECRET_KEY in environment does not appear to be a valid Stripe secret key (should start with sk_). Check the Settings menu.");
      return null;
    }

    stripeClient = new Stripe(key, {
      apiVersion: "2025-01-27.acacia" as any,
    });
  }
  return stripeClient;
}

// Lazy initialize Resend
let resendClient: Resend | null = null;
function getResend() {
  if (!resendClient && process.env.RESEND_API_KEY) {
    resendClient = new Resend(process.env.RESEND_API_KEY);
  }
  return resendClient;
}

// Stripe Webhook needs raw body
app.post("/api/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const stripe = getStripe();
  if (!stripe) return res.status(500).json({ error: "Stripe not configured" });

  const sig = req.headers["stripe-signature"] as string;
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET || ""
    );
  } catch (err: any) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the event
  switch (event.type) {
    case "checkout.session.completed":
      const session = event.data.object as Stripe.Checkout.Session;
      console.log("Payment successful for:", session.customer_details?.email);
      // Here you would typically update Firestore via Firebase Admin SDK if needed
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
});

// JSON body parser for other routes
app.use(express.json());

// API: Create Stripe Checkout Session
app.post("/api/create-checkout-session", async (req, res) => {
  const { packageId, packageName, price, monthlyFee, customerName, email, businessName } = req.body;
  const stripe = getStripe();

  if (!stripe) {
    const key = process.env.STRIPE_SECRET_KEY;
    let message = "Stripe is not configured. Please add STRIPE_SECRET_KEY in the Settings menu.";
    if (key && !key.startsWith('sk_')) {
      message = "The STRIPE_SECRET_KEY in your Settings menu is invalid. It must start with 'sk_test_' or 'sk_live_'.";
    }
    return res.status(500).json({ error: message });
  }

  try {
    const lineItems: any[] = [
      {
        price_data: {
          currency: "gbp",
          product_data: {
            name: `${packageName} (SyncSites Co.)`,
            description: `Professional Website Build for ${businessName}`,
          },
          unit_amount: price * 100, // Stripe expects pence/cents
        },
        quantity: 1,
      },
    ];

    if (monthlyFee > 0) {
      lineItems.push({
        price_data: {
          currency: "gbp",
          product_data: {
            name: "Monthly Growth Support",
            description: "Ongoing maintenance, hosting, and SEO optimization.",
          },
          unit_amount: monthlyFee * 100,
          recurring: { interval: "month" },
        },
        quantity: 1,
      });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: monthlyFee > 0 ? "subscription" : "payment",
      success_url: `${req.headers.origin}/checkout?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.origin}/checkout?canceled=true`,
      customer_email: email,
      metadata: {
        customerName,
        businessName,
        packageId,
      },
    });

    res.json({ id: session.id, url: session.url });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API: Send Contact Email (Proxy)
app.post("/api/contact", async (req, res) => {
  const { name, email, message } = req.body;
  const resend = getResend();

  if (!resend) {
    // If not configured, just log it. In a real app, you'd want to handle this.
    console.log("Email not sent (Resend not configured):", { name, email, message });
    return res.json({ success: true, message: "Mock success - configure RESEND_API_KEY for real emails." });
  }

  try {
    await resend.emails.send({
      from: "SyncSites Co. <onboarding@resend.dev>", // Replace with your domain once verified
      to: ["hamzakashem1+syncsites@gmail.com"], // Hardcoded for demo/lead notification
      subject: `New Lead: ${name} from SyncSites.co`,
      html: `
        <h2>New Inquiry from ${name}</h2>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong> ${message}</p>
      `,
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API: Chatbot Assistant powered by Gemini 3.5-flash
app.post("/api/chat", async (req, res) => {
  const { message, history } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  const ai = getGemini();
  if (!ai) {
    console.warn("WARNING: GEMINI_API_KEY environment variable is not defined in Settings > Secrets. Falling back to informative mode.");
    return res.json({ 
      text: "Hello! I am SyncBot, the official AI Assistant for SyncSites Co.\n\nTo unlock my full AI capabilities, please specify your **GEMINI_API_KEY** in the **Settings > Secrets** panel of AI Studio.\n\nIn the meantime, I'm happy to tell you about our professional web design packages:\n- **Basic Website Package (£150)**: Professional website build, setup, publishing, mobile responsive, standard pages, one-time build fee.\n- **Bespoke Website Package (£299)**: Fully custom tailored website, collaborative planning, advanced layouts.\n- **Monthly Management Fee (£20 essential / £49.99 premium)**: Covers professional hosting, ongoing technical maintenance, fixing visual/code errors, performance monitoring, keeping the website operational, and content updates on request.",
      isDemo: true 
    });
  }

  try {
    const formattedHistory = Array.isArray(history) 
      ? history.map((item: any) => ({
          role: item.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: item.content || item.text }]
        }))
      : [];

    const systemInstruction = `You are "SyncBot", the official AI Chatbot Assistant for "SyncSites Co." (a premium website design & management agency). 
Your objective is to provide professional, friendly, conversational, yet extremely accurate info to prospects. 

### Who is SyncSites Co.?
We are a premier custom-coded web design and website management company. We help businesses build trust, improve credibility, and establish a strong online presence. We write highly optimized, hand-crafted code from scratch. We do NOT use clunky visual page builders or WordPress. We build fast, modern, custom websites tailored precisely to business needs.

### Factual Pricing & Packages We Offer
1. **Basic Website Package (£150)**:
   - Average delivery time: 3–6 business days.
   - Includes: website build, setup, publishing, mobile optimization, standard pages (Home, About, Contact).

2. **Bespoke Website Package (£299)**:
   - Average delivery time: 7–10 business days.
   - Includes: fully custom tailored design, complex layouts, animations, CMS integration.

3. **E-Commerce Growth Package (£499)**:
   - Average delivery time: 10–14 business days.
   - Includes: online store setup, secure payment processing, product database, advanced SEO routing.

4. **Monthly Website Management Core Plan (Essential £20/mo OR Premium £49.99/mo)**:
   - Essential Care (£20/mo): Hosting, SSL, and core technical updates to keep things smooth.
   - Premium Care (£49.99/mo): Priority support, proactive maintenance, and monthly content updates requested by the client.
   - We focus on "Quick support response times" and "Fast issue resolution".

### Directives & Conversational Format
- Speak smoothly like a real elite technology consultant. Use paragraphs rather than stiff machine output. 
- You can naturally highlight the packages and redirect users gracefully to either "/packages" to browse or "/checkout" to speak with our experts directly.
- Use **Markdown** formatting to bold key terms, package names, or prices.
- Be concise. Don't overwhelm the user with long walls of text. Be helpful and prompt them with follow-up questions.
- If asked about "app development" or complex software beyond websites, say we can consult and provide custom quotes.
- End your responses with a welcoming next step, like "Would you like me to recommend a package for your business?"`;

    const chatInstance = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction,
        temperature: 0.6,
      },
      history: formattedHistory
    });

    const result = await chatInstance.sendMessage({ message });
    res.json({ text: result.text });
  } catch (err: any) {
    console.error("Chat API Error:", err);
    res.status(500).json({ error: "Failed to communicate with AI model: " + err.message });
  }
});

// API: Send Consultation & Lead Enquiry Automated Follow-Up Email
app.post("/api/enquiry", async (req, res) => {
  const { name, email, phone, businessName, packageName, price, monthlyFee, notes } = req.body;
  const resend = getResend();

  if (!resend) {
    console.log("Email not sent (Resend not configured):", { name, email, businessName, packageName });
    return res.json({ success: true, message: "Mock success - configure RESEND_API_KEY for real emails." });
  }

  try {
    // 1. Send branded confirmation copy to client
    await resend.emails.send({
      from: "SyncSites Co. Onboarding <onboarding@resend.dev>",
      to: [email],
      subject: `Your SyncSites Co. Enquiry Received — ${businessName}`,
      html: `
        <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;max-width:600px;margin:0 auto;padding:40px 20px;background-color:#050505;color:#ffffff;border-radius:16px;">
          <h2 style="font-size:24px;font-weight:bold;margin-bottom:16px;color:#3b82f6;text-transform:uppercase;letter-spacing:-0.5px;">Enquiry Confirmed</h2>
          <p style="font-size:16px;line-height: relaxed;color:#cccccc;margin-bottom:24px;">
            Hello ${name},
          </p>
          <p style="font-size:15px;line-height:1.6;color:#bbbbbb;margin-bottom:24px;">
            Your enquiry has been received. A developer from <strong>SyncSites Co.</strong> will review your request and contact you shortly to host a secure consultation.
          </p>
          
          <div style="background-color:#111111;border:1px solid #222222;border-radius:12px;padding:20px;margin-bottom:24px;">
            <h3 style="margin-top:0;font-size:14px;color:#888888;text-transform:uppercase;letter-spacing:1px;margin-bottom:16px;">Enquiry Details</h3>
            <table style="width:100%;font-size:14px;color:#cccccc;">
              <tr>
                <td style="padding:4px 0;font-weight:bold;color:#888888;">Company:</td>
                <td style="padding:4px 0;text-align:right;color:#ffffff;">${businessName}</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-weight:bold;color:#888888;">Package:</td>
                <td style="padding:4px 0;text-align:right;color:#ffffff;">${packageName}</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-weight:bold;color:#888888;">Setup Fee Estimate:</td>
                <td style="padding:4px 0;text-align:right;color:#3b82f6;font-weight:bold;">£${price}</td>
              </tr>
              ${monthlyFee && monthlyFee > 0 ? `
              <tr>
                <td style="padding:4px 0;font-weight:bold;color:#888888;">Monthly Support:</td>
                <td style="padding:4px 0;text-align:right;color:#3b82f6;font-weight:bold;">£${monthlyFee}/mo</td>
              </tr>
              ` : ''}
            </table>
          </div>

          <p style="font-size:12px;color:#666666;line-height:1.5;margin-top:40px;border-top:1px solid #222222;padding-top:20px;">
            This email was sent by SyncSites Co. Website design, mobile-responsive layout publishing, and ongoing website management solutions for modern businesses.
          </p>
        </div>
      `,
    });

    // 2. Notify the SyncSites admin team of the fresh lead
    await resend.emails.send({
      from: "SyncSites CRM <onboarding@resend.dev>",
      to: ["hamzakashem1+syncsites@gmail.com"],
      subject: `New Customer Lead Alert: ${businessName}`,
      html: `
        <h2>Fresh Package Hold Placed!</h2>
        <p><strong>Customer Name:</strong> ${name}</p>
        <p><strong>Business:</strong> ${businessName}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone}</p>
        <p><strong>Package Type:</strong> ${packageName} (£${price} setup, £${monthlyFee || 0}/mo)</p>
        <p><strong>Provided Briefing Details:</strong> ${notes || "None"}</p>
      `
    });

    res.json({ success: true });
  } catch (err: any) {
    console.error("Enquiry Email Error:", err);
    res.status(500).json({ error: "Failed to send verification notification email." });
  }
});

// API: Check Integration Status
app.get("/api/admin/config-status", async (req, res) => {
  // Simple check - in production, we might want to verify with actual API calls
  res.json({
    stripe: !!process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY.startsWith('sk_'),
    resend: !!process.env.RESEND_API_KEY,
    webhook: !!process.env.STRIPE_WEBHOOK_SECRET,
  });
});

// Vite middleware for development
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupServer();
