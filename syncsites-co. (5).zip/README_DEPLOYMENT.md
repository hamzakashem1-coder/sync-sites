# Deployment & Go-Live Guide: SyncSites Co.

Welcome to your production-ready business platform. Follow these steps to complete the setup and start accepting payments.

## 1. Environment Variables
Ensure the following variables are set in your hosting platform (e.g., Vercel) and locally for development:

| Key | Description | Where to get it |
|-----|-------------|-----------------|
| `STRIPE_SECRET_KEY` | Your Stripe API secret key | Stripe Dashboard -> Developers -> API Keys |
| `STRIPE_WEBHOOK_SECRET` | Secret to verify Stripe webhooks | Stripe Dashboard -> Webhooks -> Add endpoint (`/api/webhook`) |
| `RESEND_API_KEY` | API Key for sending lead notifications | Resend.com -> API Keys |
| `ADMIN_PASSWORD` | Optional password layer for dashboard | Create your own (e.g., `SyncLegacy2026`) |

## 2. Stripe Configuration
To support subscriptions and Apple Pay:
1. Go to **Stripe Dashboard**.
2. Enable **Checkout** and **Subscriptions**.
3. (Optional) Set up your branding (logo, primary color) so the Stripe checkout page matches your site.
4. Add the webhook endpoint `https://your-domain.com/api/webhook` and listen for `checkout.session.completed`.

## 3. Firebase Configuration
1. Your Firebase database and rules are already deployed.
2. To grant additional Admin access:
   - Go to Firestore -> `admins` collection.
   - Create a document with the `UID` of the user and leave it blank (the presence of the UID grants access).

## 4. Domain & Professional Email
1. Connect your custom domain `syncsitesco.com` (or similar) via Vercel/Cloudflare.
2. Set up **Google Workspace** for `hello@syncsitesco.com`.

## 5. Launch Checklist
- [ ] Test the contact form (check Firestore `leads` collection).
- [ ] Test a checkout session (use Stripe Test Mode).
- [ ] Verify lead notification emails in Resend (if configured).
- [ ] Confirm mobile responsiveness on real devices.

---
**SyncSites Co.** — *Transforming visitors into revenue.*
